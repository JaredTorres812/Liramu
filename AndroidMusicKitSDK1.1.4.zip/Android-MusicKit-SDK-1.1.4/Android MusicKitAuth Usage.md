# MusicKit for Android - Authentication API

## Overview

The MusicKitAuth SDK lets your app authenticate users with Apple Music and obtain a
Music User Token (MUT). This token, combined with your Developer Token, authorizes
your app to access the Apple Music API and play subscription content on behalf of
the user.

Authentication works through a deeplink handoff to the Apple Music app, which
handles Apple ID sign-in, subscription validation, and token generation. Your app
never sees the user's Apple ID credentials. Alternatively, if you use 
link.apple.com you can skip the deeplink flow and send the MUT directly,
see "Providing an Already-Obtained MUT" section

## Prerequisites

- An Apple Developer account with a MusicKit key
- A Developer Token (JWT signed with your MusicKit private key)
- The user's device must be able to install Apple Music from Google Play

## How Authentication Works

    ┌──────────────┐         ┌──────────────┐         ┌─────────────────┐
    │   Your App   │         │ MusicKitAuth │         │   Apple Music   │
    └──────┬───────┘         └──────┬───────┘         └────────┬────────┘
           │                        │                          │
           │  1. Build auth intent  │                          │
           │  with developer token  │                          │
           │───────────────────────>│                          │
           │                        │                          │
           │                        │  2. Deeplink to          │
           │                        │  Apple Music with token  │
           │                        │─────────────────────────>│
           │                        │                          │
           │                        │                          │  3. User signs in
           │                        │                          │     with Apple ID
           │                        │                          │
           │                        │                          │  4. Validates
           │                        │                          │     subscription
           │                        │                          │
           │                        │  5. Returns MUT +        │
           │                        │     storefront           │
           │                        │<─────────────────────────│
           │                        │                          │
           │  6. TokenResult with   │                          │
           │  MUT, storefront, or   │                          │
           │  error code            │                          │
           │<───────────────────────│                          │
           │                        │                          │

    If Apple Music is not installed, MusicKitAuth shows a prompt to install
    it from Google Play before proceeding with authentication.
    MusicKitAuth also handles token refresh automatically.

## Manifest Configuration

Register the SDK's URI handler activity in your AndroidManifest.xml. This
activity receives authentication callbacks from Apple Music:

    <activity
        android:name="com.apple.android.sdk.authentication.SDKUriHandlerActivity"
        tools:node="merge" />

You also need to declare that your app queries for Apple Music, so the SDK can
check whether it is installed:

    <queries>
        <package android:name="com.apple.android.music" />
    </queries>

## Creating an AuthenticationManager

Create a single `AuthenticationManager` instance for your app. This is the
entry point for all authentication operations.

    import com.apple.android.sdk.authentication.AuthenticationFactory;
    import com.apple.android.sdk.authentication.AuthenticationManager;

    AuthenticationManager authManager = AuthenticationFactory.createAuthenticationManager(context);

## Starting the Authentication Flow

Build an authentication intent and launch it with `startActivityForResult`.
The intent builder requires your Developer Token and provides optional
configuration for the consent screen:

    import com.apple.android.sdk.authentication.AuthIntentBuilder;

    String developerToken = "eyJhbGciOiJFUzI1NiI...";  // Your JWT

    Intent intent = authManager.createIntentBuilder(developerToken)
        .setHideStartScreen(true)
        .setStartScreenMessage("Connect to Apple Music to play full tracks")
        .build();

    startActivityForResult(intent, REQUEST_CODE_APPLE_MUSIC_AUTH);

### Intent Builder Options

| Method                              | Description                                                      |
|-------------------------------------|------------------------------------------------------------------|
| `setHideStartScreen(boolean)`       | If `true`, skips the consent screen and deeplinks directly to Apple Music. If `false` (default), shows a branded screen with a "Connect to Apple Music" button. |
| `setStartScreenMessage(String)`     | Custom message displayed on the consent screen. Only shown when `hideStartScreen` is `false`. |
| `setContextId(String)`              | An Apple Music catalog ID (e.g. a song or playlist). Apple Music may use this to show relevant artwork during the subscription upsell. |
| `setCustomParams(HashMap)`          | Additional key-value parameters passed through to Apple Music (e.g. affiliate tokens). |

### What Happens During Authentication

When `hideStartScreen` is `false`, the consent screen's button label
adapts to the device state:

- **"Connect to Apple Music"** if Apple Music is installed and up to date
- **"Update Apple Music"** if an older version is installed
- **"Install Apple Music"** if not installed (redirects to Google Play)

## Handling the Authentication Result

In your activity's `onActivityResult`, pass the returned intent to
`handleTokenResult` to extract the authentication result:

    import com.apple.android.sdk.authentication.TokenResult;
    import com.apple.android.sdk.authentication.TokenError;

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_CODE_APPLE_MUSIC_AUTH) {
            TokenResult result = authManager.handleTokenResult(data);

            if (!result.isError()) {
                // Authentication succeeded
                String musicUserToken = result.getMusicUserToken();
                String storefront = result.getStorefrontId();
                String appleMusicStorefront = result.getAppleMusicStorefrontId();

                // Store these securely, will need them to access Media API endpoints
                // and to create a TokenProvider for the playback SDK.
                saveTokens(musicUserToken, storefront, appleMusicStorefront);
            } else {
                // Authentication failed
                TokenError error = result.getError();
                handleAuthError(error);
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

### TokenResult Fields

| Method                        | Description                                                   |
|-------------------------------|---------------------------------------------------------------|
| `isError()`                   | `true` if authentication failed                               |
| `getMusicUserToken()`         | The Music User Token (MUT) for the Apple Music API            |
| `getStorefrontId()`           | The user's storefront (e.g. `"us"`, `"gb"`)                   |
| `getAppleMusicStorefrontId()` | An encoded storefront identifier for Apple Music API requests |
| `getError()`                  | A `TokenError` enum value describing what went wrong          |

### TokenError Values

| Value                  | Meaning                                  | Suggested Action                      |
|------------------------|------------------------------------------|---------------------------------------|
| `USER_CANCELLED`       | The user dismissed the sign-in flow      | Allow retry, do not show error        |
| `NO_SUBSCRIPTION`      | The user has no Apple Music subscription | Show subscription required message    |
| `SUBSCRIPTION_EXPIRED` | The user's subscription has expired      | Prompt to renew subscription          |
| `TOKEN_FETCH_ERROR`    | Apple Music failed to create a token     | Retry, or show generic error          |
| `UNKNOWN`              | An unexpected error occurred             | Log for diagnostics, show generic error |

## Implementing TokenProvider

Both the authentication SDK (`refreshTokenAsync`) and the playback SDK
(`MediaPlayerControllerFactory`) require a `TokenProvider`. This interface
supplies the credentials needed for API access:

    import com.apple.android.sdk.authentication.TokenProvider;

    public class MyTokenProvider implements TokenProvider {

        @Override
        public String getDeveloperToken() {
            // Return your Developer Token JWT.
            // Check expiration and refresh if needed 
            return storedDeveloperToken;
        }

        @Override
        public String getUserToken() {
            // Return the Music User Token obtained from authentication.
            // Returns null if the user has not authenticated yet.
            return storedMusicUserToken;
        }

        @Override
        public String getAppleMusicStoreFrontId() {
            // Return the storefront ID obtained from authentication.
            // Used by the playback SDK to resolve catalog content.
            return storedAppleMusicStoreFrontId;
        }
    }

## Providing an Already-Obtained MUT

If your app obtains the Music User Token outside of MusicKitAuth — e.g. 
link.apple.com, you do **not** call `createIntentBuilder` or
`handleTokenResult`. You just pass the MUT, devToken, and storefront directly.

Store the values in your implementation of the `TokenProvider`, then notify the
playback controller that tokens have changed. `notifyTokenChanged` reads the
three getters on your provider and copies them into the SDK's internal
cache:

    tokenStorage.setUserToken(mutFromWeb);
    tokenStorage.setDeveloperToken(devToken);
    tokenStorage.setAppleMusicStoreFrontId(storefrontId);

    player.getPlaybackStoreConfiguration()
          .notifyTokenChanged(context, tokenProvider);

## Refreshing the Music User Token

Music User Tokens expire. Use `refreshTokenAsync` to obtain a new one without
requiring the user to re-authenticate through Apple Music. This call goes
directly to Apple's servers (no Apple Music app involvement)

In the case of any token-based error, it's your responsibility to alert any
listeners and handle it gracefully 

    authManager.refreshTokenAsync(tokenProvider, new TokenRefreshListener() {

        @Override
        public void onTokenRefreshed(String newMusicUserToken) {
            // Store the new MUT and update your TokenProvider
            saveNewMusicUserToken(newMusicUserToken);
        }

        @Override
        public void onTokenError(TokenError error) {
            switch (error) {
                case SUBSCRIPTION_EXPIRED:
                case NO_SUBSCRIPTION:
                    //Playback is stopped, prompt user to re-subscribe
                    handleSubscriptionLost();
                    break;
                default:
                    // Token refresh failed - clear stored credentials, require re-authentication
                    clearStoredTokens();
                    promptReauthentication();
                    break;
            }
        }
    });


## Connecting Authentication to Playback

The MusicKitAuth and MediaPlayback SDKs are connected through the
`TokenProvider` interface. Once you have a Music User Token from
authentication, you pass the same `TokenProvider` to the playback SDK:

    // 1. Authenticate and store the MUT (see above)

    // 2. Create a TokenProvider that returns your stored credentials
    TokenProvider tokenProvider = new MyTokenProvider();

    // 3. Create the playback controller with the same TokenProvider
    MediaPlayerController player = MediaPlayerControllerFactory
        .createLocalController(context, tokenProvider);

    // The playback SDK reads getDeveloperToken() and getUserToken()
    // from your TokenProvider whenever it needs to authorize API calls
    // or decrypt streaming content.

When the MUT is refreshed or invalidated, notify the playback controller
so it can update its internal authorization state:

    player.getPlaybackStoreConfiguration()
        .notifyTokenChanged(context, tokenProvider);

## Ending a Session

MusicKitAuth does not expose a single `signOut()` or `clear()` method. 
All tokens live in your own `TokenProvider` storage and in the SDK.
To end a session cleanly, clear your own store and the SDK's,
notifying the player the tokens have changed

1. Clear your own `TokenProvider` storage so all three getters return `null`:

2. To clear the SDK's internal store, push the values from your now-null TokenProvider

        player.getPlaybackStoreConfiguration()
              .notifyTokenChanged(context, tokenProvider);

3. Stop playback and tear down any foreground surface owned by your
   service (media session, notification). See the MediaPlayback guide's
   `Terminating Session` section for the full checklist. 

## Complete Example

    public class MusicActivity extends AppCompatActivity {

        private static final int RC_AUTH = 1234;
        private AuthenticationManager authManager;
        private MyTokenProvider tokenProvider;
        private MediaPlayerController player;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);

            authManager = AuthenticationFactory.createAuthenticationManager(this);
            tokenProvider = new MyTokenProvider(this);

            if (tokenProvider.getUserToken() != null) {
                createPlayer();
            } else {
                // Need to authenticate
                startAuth();
            }
        }

        private void startAuth() {
            Intent intent = authManager.createIntentBuilder(tokenProvider.getDeveloperToken())
                .setHideStartScreen(false)
                .setStartScreenMessage("Sign in to play music")
                .build();
            startActivityForResult(intent, RC_AUTH);
        }

        @Override
        protected void onActivityResult(int requestCode, int resultCode, Intent data) {
            if (requestCode == RC_AUTH) {
                TokenResult result = authManager.handleTokenResult(data);
                if (!result.isError()) {
                    tokenProvider.store(
                        result.getMusicUserToken(),
                        result.getStorefrontId(),
                        result.getAppleMusicStorefrontId()
                    );
                    createPlayer();
                } else if (result.getError() != TokenError.USER_CANCELLED) {
                    showError(result.getError());
                }
            }
            super.onActivityResult(requestCode, resultCode, data);
        }

        private void createPlayer() {
            player = MediaPlayerControllerFactory
                .createLocalController(this, tokenProvider);
        }

        private void refreshToken() {
            authManager.refreshTokenAsync(tokenProvider, new TokenRefreshListener() {
                @Override
                public void onTokenRefreshed(String mut) {
                    tokenProvider.storeNewMut(mut);
                    if (player != null) {
                        player.getPlaybackStoreConfiguration()
                            .notifyTokenChanged(MusicActivity.this, tokenProvider);
                    }
                }

                @Override
                public void onTokenError(TokenError error) {
                    if (error == TokenError.SUBSCRIPTION_EXPIRED
                            || error == TokenError.NO_SUBSCRIPTION) {
                        stopPlaybackAndPromptResubscribe();
                    } else {
                        clearTokensAndReauthenticate();
                    }
                }
            });
        }

        @Override
        protected void onDestroy() {
            if (player != null) {
                player.release();
            }
            super.onDestroy();
        }
    }