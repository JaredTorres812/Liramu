# Changelog
All notable changes to this project will be documented in this file.

## [1.1.4] - 2026-05-07
- Fixed live radio station playback 

## [1.1.3] - 2026-04-28

### MediaPlayback
- Added audio variant reporting via `MediaPlayerController.getAudioVariant()` and `AudioConstants.TRACK_VARIANTS_*`
- Added more queue management APIs
- Added `MediaPlayerContextFactory.createPlayerContext()` for clearing SDK internal state
- Added `PlaybackStoreConfigurationProxy.notifyTokenChanged()`, `notifySubscriptionChanged()`, `restoreState` for token and playback lifecycle management
- Upgraded NDK to 28.1.13356709, compileSdk/targetSdk to 34, Kotlin to 1.9.23, AGP to 8.3.1
- Added 16KB page size support for Android 15+ 

### MusicKitAuth
- Added `TokenProvider.getAppleMusicStoreFrontId()` to supply encoded storefront ID to the playback SDK
- Upgraded compileSdk/targetSdk to 34, Kotlin to 1.9.23, AGP to 8.3.1

### Documentation
- Added "Android MusicKitAuth Usage" guide covering authentication flow, token management, and token refresh
- Added "Android MediaPlayback Usage" guide covering controller lifecycle, queue providers, listener callbacks, error handling, and complete integration example
- Updated build.gradle minimum working example to a kotlin dsl build.gradle.kts

## [1.1.2] - 2021-11-16
- 15 new languages added (Czech, Hungarian, Indonesian, Malay, Romanian, Slovak, Ukrainian, Vietnamese, Catalan, Canadian French, Greek, Latin American Spanish, Croation, Arabic RTL, Hebrew RTL)

## [1.1.1] - 2020-05-06
- Fixed bugs and improved playback performance

## [1.0.0] - 2019-07-31
- Promoted from Beta.
- Final release with support for AppCompat v7:28

### Added
- Promoted from Beta
- Added 64 bit native library support 

## [0.9.2] - 2019-07-05
- Initial public beta release of Android MusicKit.

