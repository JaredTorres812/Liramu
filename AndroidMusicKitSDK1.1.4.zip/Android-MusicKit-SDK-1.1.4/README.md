[Contents:
- api-docs
- sdk-test-app 
- Android MediaPlayback Usage.md
- Android MusicKit Examples.md 
- Android MusicKitAuth Usage.md
- CHANGELOG.md
- MediaPlayback-release-1.1.4.aar
- MusicKitAuth-release-1.1.5.aar

Using this MusicKit release:

`api-docs` contains documentation for all public methods of MediaPlayback. You can open 
`MediaPlayback/index.html` in a web browser to load a kotlinlang.org style view of these class
and method signatures

`sdk-test-app` contains a minimal example of how a sample app might use MediaPlayback and MusicKitAuth

`Android MediaPlayback Usage.md` and `Android MusicKitAuth Usage.md` contain detailed examples
of how to use the most relevant methods 

`Android MusicKit Examples.md` is a quick higher-level summary of these modules

`MediaPlayback-release-1.1.4.aar` and `MusicKitAuth-release-1.1.5.aar` are the two MusicKit modules
your app must consume