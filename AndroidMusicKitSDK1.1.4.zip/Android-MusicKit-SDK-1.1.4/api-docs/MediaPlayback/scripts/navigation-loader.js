const __dokkaNavigation = `<div class="sideMenuPart" id="MediaPlayback-nav-submenu" pageId="MediaPlayback::////PointingToDeclaration//-357955546">
  <div class="overview"><span class="navButton" onclick="document.getElementById(&quot;MediaPlayback-nav-submenu&quot;).classList.toggle(&quot;hidden&quot;);"><span class="navButtonContent"></span></span><a href="index.html"><span>Media</span><wbr></wbr><span><span>Playback</span></span></a></div>
  <div class="sideMenuPart" id="MediaPlayback-nav-submenu-0" pageId="MediaPlayback::com.apple.android.music.playback.controller////PointingToDeclaration//-357955546">
    <div class="overview"><span class="navButton" onclick="document.getElementById(&quot;MediaPlayback-nav-submenu-0&quot;).classList.toggle(&quot;hidden&quot;);"><span class="navButtonContent"></span></span><a href="-media-playback/com.apple.android.music.playback.controller/index.html"><span>com.</span><wbr></wbr><span>apple.</span><wbr></wbr><span>android.</span><wbr></wbr><span>music.</span><wbr></wbr><span>playback.</span><wbr></wbr><span>controller</span></a></div>
    <div class="sideMenuPart" id="MediaPlayback-nav-submenu-0-0" pageId="MediaPlayback::com.apple.android.music.playback.controller/MediaPlayerController///PointingToDeclaration//-357955546">
      <div class="overview"><span class="navButton" onclick="document.getElementById(&quot;MediaPlayback-nav-submenu-0-0&quot;).classList.toggle(&quot;hidden&quot;);"><span class="navButtonContent"></span></span><a href="-media-playback/com.apple.android.music.playback.controller/-media-player-controller/index.html"><span class="nav-link-grid"><span class="nav-link-child nav-icon interface"></span><span class="nav-link-child"><span>Media</span><wbr></wbr><span>Player</span><wbr></wbr><span><span>Controller</span></span></span></span></a></div>
      <div class="sideMenuPart" id="MediaPlayback-nav-submenu-0-0-0" pageId="MediaPlayback::com.apple.android.music.playback.controller/MediaPlayerController.Listener///PointingToDeclaration//-357955546">
        <div class="overview"><a href="-media-playback/com.apple.android.music.playback.controller/-media-player-controller/-listener/index.html"><span class="nav-link-grid"><span class="nav-link-child nav-icon interface"></span><span class="nav-link-child"><span><span>Listener</span></span></span></span></a></div>
      </div>
    </div>
    <div class="sideMenuPart" id="MediaPlayback-nav-submenu-0-1" pageId="MediaPlayback::com.apple.android.music.playback.controller/MediaPlayerControllerFactory///PointingToDeclaration//-357955546">
      <div class="overview"><a href="-media-playback/com.apple.android.music.playback.controller/-media-player-controller-factory/index.html"><span class="nav-link-grid"><span class="nav-link-child nav-icon class"></span><span class="nav-link-child"><span>Media</span><wbr></wbr><span>Player</span><wbr></wbr><span>Controller</span><wbr></wbr><span><span>Factory</span></span></span></span></a></div>
    </div>
  </div>
  <div class="sideMenuPart" id="MediaPlayback-nav-submenu-1" pageId="MediaPlayback::com.apple.android.music.playback.model////PointingToDeclaration//-357955546">
    <div class="overview"><span class="navButton" onclick="document.getElementById(&quot;MediaPlayback-nav-submenu-1&quot;).classList.toggle(&quot;hidden&quot;);"><span class="navButtonContent"></span></span><a href="-media-playback/com.apple.android.music.playback.model/index.html"><span>com.</span><wbr></wbr><span>apple.</span><wbr></wbr><span>android.</span><wbr></wbr><span>music.</span><wbr></wbr><span>playback.</span><wbr></wbr><span>model</span></a></div>
    <div class="sideMenuPart" id="MediaPlayback-nav-submenu-1-0" pageId="MediaPlayback::com.apple.android.music.playback.model/AudioQuality///PointingToDeclaration//-357955546">
      <div class="overview"><span class="navButton" onclick="document.getElementById(&quot;MediaPlayback-nav-submenu-1-0&quot;).classList.toggle(&quot;hidden&quot;);"><span class="navButtonContent"></span></span><a href="-media-playback/com.apple.android.music.playback.model/-audio-quality/index.html"><span class="nav-link-grid"><span class="nav-link-child nav-icon enum-class-kt"></span><span class="nav-link-child"><span>Audio</span><wbr></wbr><span><span>Quality</span></span></span></span></a></div>
      <div class="sideMenuPart" id="MediaPlayback-nav-submenu-1-0-0" pageId="MediaPlayback::com.apple.android.music.playback.model/AudioQuality.HIGH_EFFICIENCY///PointingToDeclaration/{&quot;org.jetbrains.dokka.links.EnumEntryDRIExtra&quot;:{&quot;key&quot;:&quot;org.jetbrains.dokka.links.EnumEntryDRIExtra&quot;}}/-357955546">
        <div class="overview"><a href="-media-playback/com.apple.android.music.playback.model/-audio-quality/-h-i-g-h_-e-f-f-i-c-i-e-n-c-y/index.html"><span class="nav-link-grid"><span class="nav-link-child nav-icon enum-class-kt"></span><span class="nav-link-child"><span><span>HIGH_EFFICIENCY</span></span></span></span></a></div>
      </div>
      <div class="sideMenuPart" id="MediaPlayback-nav-submenu-1-0-1" pageId="MediaPlayback::com.apple.android.music.playback.model/AudioQuality.HIGH_QUALITY///PointingToDeclaration/{&quot;org.jetbrains.dokka.links.EnumEntryDRIExtra&quot;:{&quot;key&quot;:&quot;org.jetbrains.dokka.links.EnumEntryDRIExtra&quot;}}/-357955546">
        <div class="overview"><a href="-media-playback/com.apple.android.music.playback.model/-audio-quality/-h-i-g-h_-q-u-a-l-i-t-y/index.html"><span class="nav-link-grid"><span class="nav-link-child nav-icon enum-class-kt"></span><span class="nav-link-child"><span><span>HIGH_QUALITY</span></span></span></span></a></div>
      </div>
      <div class="sideMenuPart" id="MediaPlayback-nav-submenu-1-0-2" pageId="MediaPlayback::com.apple.android.music.playback.model/AudioQuality.LOSSLESS///PointingToDeclaration/{&quot;org.jetbrains.dokka.links.EnumEntryDRIExtra&quot;:{&quot;key&quot;:&quot;org.jetbrains.dokka.links.EnumEntryDRIExtra&quot;}}/-357955546">
        <div class="overview"><a href="-media-playback/com.apple.android.music.playback.model/-audio-quality/-l-o-s-s-l-e-s-s/index.html"><span class="nav-link-grid"><span class="nav-link-child nav-icon enum-class-kt"></span><span class="nav-link-child"><span><span>LOSSLESS</span></span></span></span></a></div>
      </div>
      <div class="sideMenuPart" id="MediaPlayback-nav-submenu-1-0-3" pageId="MediaPlayback::com.apple.android.music.playback.model/AudioQuality.HIGH_RES_LOSSLESS///PointingToDeclaration/{&quot;org.jetbrains.dokka.links.EnumEntryDRIExtra&quot;:{&quot;key&quot;:&quot;org.jetbrains.dokka.links.EnumEntryDRIExtra&quot;}}/-357955546">
        <div class="overview"><a href="-media-playback/com.apple.android.music.playback.model/-audio-quality/-h-i-g-h_-r-e-s_-l-o-s-s-l-e-s-s/index.html"><span class="nav-link-grid"><span class="nav-link-child nav-icon enum-class-kt"></span><span class="nav-link-child"><span><span>HIGH_RES_LOSSLESS</span></span></span></span></a></div>
      </div>
      <div class="sideMenuPart" id="MediaPlayback-nav-submenu-1-0-4" pageId="MediaPlayback::com.apple.android.music.playback.model/AudioQuality.DOLBY_ATMOS///PointingToDeclaration/{&quot;org.jetbrains.dokka.links.EnumEntryDRIExtra&quot;:{&quot;key&quot;:&quot;org.jetbrains.dokka.links.EnumEntryDRIExtra&quot;}}/-357955546">
        <div class="overview"><a href="-media-playback/com.apple.android.music.playback.model/-audio-quality/-d-o-l-b-y_-a-t-m-o-s/index.html"><span class="nav-link-grid"><span class="nav-link-child nav-icon enum-class-kt"></span><span class="nav-link-child"><span><span>DOLBY_ATMOS</span></span></span></span></a></div>
      </div>
      <div class="sideMenuPart" id="MediaPlayback-nav-submenu-1-0-5" pageId="MediaPlayback::com.apple.android.music.playback.model/AudioQuality.NONE///PointingToDeclaration/{&quot;org.jetbrains.dokka.links.EnumEntryDRIExtra&quot;:{&quot;key&quot;:&quot;org.jetbrains.dokka.links.EnumEntryDRIExtra&quot;}}/-357955546">
        <div class="overview"><a href="-media-playback/com.apple.android.music.playback.model/-audio-quality/-n-o-n-e/index.html"><span class="nav-link-grid"><span class="nav-link-child nav-icon enum-class-kt"></span><span class="nav-link-child"><span><span>NONE</span></span></span></span></a></div>
      </div>
    </div>
    <div class="sideMenuPart" id="MediaPlayback-nav-submenu-1-1" pageId="MediaPlayback::com.apple.android.music.playback.model/DolbyAtmosState///PointingToDeclaration//-357955546">
      <div class="overview"><span class="navButton" onclick="document.getElementById(&quot;MediaPlayback-nav-submenu-1-1&quot;).classList.toggle(&quot;hidden&quot;);"><span class="navButtonContent"></span></span><a href="-media-playback/com.apple.android.music.playback.model/-dolby-atmos-state/index.html"><span class="nav-link-grid"><span class="nav-link-child nav-icon enum-class-kt"></span><span class="nav-link-child"><span>Dolby</span><wbr></wbr><span>Atmos</span><wbr></wbr><span><span>State</span></span></span></span></a></div>
      <div class="sideMenuPart" id="MediaPlayback-nav-submenu-1-1-0" pageId="MediaPlayback::com.apple.android.music.playback.model/DolbyAtmosState.AUTOMATIC///PointingToDeclaration/{&quot;org.jetbrains.dokka.links.EnumEntryDRIExtra&quot;:{&quot;key&quot;:&quot;org.jetbrains.dokka.links.EnumEntryDRIExtra&quot;}}/-357955546">
        <div class="overview"><a href="-media-playback/com.apple.android.music.playback.model/-dolby-atmos-state/-a-u-t-o-m-a-t-i-c/index.html"><span class="nav-link-grid"><span class="nav-link-child nav-icon enum-class-kt"></span><span class="nav-link-child"><span><span>AUTOMATIC</span></span></span></span></a></div>
      </div>
      <div class="sideMenuPart" id="MediaPlayback-nav-submenu-1-1-1" pageId="MediaPlayback::com.apple.android.music.playback.model/DolbyAtmosState.ALWAYS_ON///PointingToDeclaration/{&quot;org.jetbrains.dokka.links.EnumEntryDRIExtra&quot;:{&quot;key&quot;:&quot;org.jetbrains.dokka.links.EnumEntryDRIExtra&quot;}}/-357955546">
        <div class="overview"><a href="-media-playback/com.apple.android.music.playback.model/-dolby-atmos-state/-a-l-w-a-y-s_-o-n/index.html"><span class="nav-link-grid"><span class="nav-link-child nav-icon enum-class-kt"></span><span class="nav-link-child"><span><span>ALWAYS_ON</span></span></span></span></a></div>
      </div>
      <div class="sideMenuPart" id="MediaPlayback-nav-submenu-1-1-2" pageId="MediaPlayback::com.apple.android.music.playback.model/DolbyAtmosState.OFF///PointingToDeclaration/{&quot;org.jetbrains.dokka.links.EnumEntryDRIExtra&quot;:{&quot;key&quot;:&quot;org.jetbrains.dokka.links.EnumEntryDRIExtra&quot;}}/-357955546">
        <div class="overview"><a href="-media-playback/com.apple.android.music.playback.model/-dolby-atmos-state/-o-f-f/index.html"><span class="nav-link-grid"><span class="nav-link-child nav-icon enum-class-kt"></span><span class="nav-link-child"><span><span>OFF</span></span></span></span></a></div>
      </div>
    </div>
    <div class="sideMenuPart" id="MediaPlayback-nav-submenu-1-2" pageId="MediaPlayback::com.apple.android.music.playback.model/ErrorConditionException///PointingToDeclaration//-357955546">
      <div class="overview"><a href="-media-playback/com.apple.android.music.playback.model/-error-condition-exception/index.html"><span class="nav-link-grid"><span class="nav-link-child nav-icon exception-class"></span><span class="nav-link-child"><span>Error</span><wbr></wbr><span>Condition</span><wbr></wbr><span><span>Exception</span></span></span></span></a></div>
    </div>
    <div class="sideMenuPart" id="MediaPlayback-nav-submenu-1-3" pageId="MediaPlayback::com.apple.android.music.playback.model/MediaContainerType///PointingToDeclaration//-357955546">
      <div class="overview"><a href="-media-playback/com.apple.android.music.playback.model/-media-container-type/index.html"><span class="nav-link-grid"><span class="nav-link-child nav-icon annotation-class"></span><span class="nav-link-child"><span>Media</span><wbr></wbr><span>Container</span><wbr></wbr><span><span>Type</span></span></span></span></a></div>
    </div>
    <div class="sideMenuPart" id="MediaPlayback-nav-submenu-1-4" pageId="MediaPlayback::com.apple.android.music.playback.model/MediaItemLocation///PointingToDeclaration//-357955546">
      <div class="overview"><a href="-media-playback/com.apple.android.music.playback.model/-media-item-location/index.html"><span class="nav-link-grid"><span class="nav-link-child nav-icon annotation-class"></span><span class="nav-link-child"><span>Media</span><wbr></wbr><span>Item</span><wbr></wbr><span><span>Location</span></span></span></span></a></div>
    </div>
    <div class="sideMenuPart" id="MediaPlayback-nav-submenu-1-5" pageId="MediaPlayback::com.apple.android.music.playback.model/MediaItemType///PointingToDeclaration//-357955546">
      <div class="overview"><a href="-media-playback/com.apple.android.music.playback.model/-media-item-type/index.html"><span class="nav-link-grid"><span class="nav-link-child nav-icon annotation-class"></span><span class="nav-link-child"><span>Media</span><wbr></wbr><span>Item</span><wbr></wbr><span><span>Type</span></span></span></span></a></div>
    </div>
    <div class="sideMenuPart" id="MediaPlayback-nav-submenu-1-6" pageId="MediaPlayback::com.apple.android.music.playback.model/MediaPlayerException///PointingToDeclaration//-357955546">
      <div class="overview"><a href="-media-playback/com.apple.android.music.playback.model/-media-player-exception/index.html"><span class="nav-link-grid"><span class="nav-link-child nav-icon exception-class"></span><span class="nav-link-child"><span>Media</span><wbr></wbr><span>Player</span><wbr></wbr><span><span>Exception</span></span></span></span></a></div>
    </div>
    <div class="sideMenuPart" id="MediaPlayback-nav-submenu-1-7" pageId="MediaPlayback::com.apple.android.music.playback.model/MediaPlayerTrackInfo///PointingToDeclaration//-357955546">
      <div class="overview"><a href="-media-playback/com.apple.android.music.playback.model/-media-player-track-info/index.html"><span class="nav-link-grid"><span class="nav-link-child nav-icon class"></span><span class="nav-link-child"><span>Media</span><wbr></wbr><span>Player</span><wbr></wbr><span>Track</span><wbr></wbr><span><span>Info</span></span></span></span></a></div>
    </div>
    <div class="sideMenuPart" id="MediaPlayback-nav-submenu-1-8" pageId="MediaPlayback::com.apple.android.music.playback.model/PlaybackQueueMoveTargetType///PointingToDeclaration//-357955546">
      <div class="overview"><a href="-media-playback/com.apple.android.music.playback.model/-playback-queue-move-target-type/index.html"><span class="nav-link-grid"><span class="nav-link-child nav-icon annotation-class"></span><span class="nav-link-child"><span>Playback</span><wbr></wbr><span>Queue</span><wbr></wbr><span>Move</span><wbr></wbr><span>Target</span><wbr></wbr><span><span>Type</span></span></span></span></a></div>
    </div>
    <div class="sideMenuPart" id="MediaPlayback-nav-submenu-1-9" pageId="MediaPlayback::com.apple.android.music.playback.model/PlaybackRepeatMode///PointingToDeclaration//-357955546">
      <div class="overview"><a href="-media-playback/com.apple.android.music.playback.model/-playback-repeat-mode/index.html"><span class="nav-link-grid"><span class="nav-link-child nav-icon annotation-class"></span><span class="nav-link-child"><span>Playback</span><wbr></wbr><span>Repeat</span><wbr></wbr><span><span>Mode</span></span></span></span></a></div>
    </div>
    <div class="sideMenuPart" id="MediaPlayback-nav-submenu-1-10" pageId="MediaPlayback::com.apple.android.music.playback.model/PlaybackShuffleMode///PointingToDeclaration//-357955546">
      <div class="overview"><a href="-media-playback/com.apple.android.music.playback.model/-playback-shuffle-mode/index.html"><span class="nav-link-grid"><span class="nav-link-child nav-icon annotation-class"></span><span class="nav-link-child"><span>Playback</span><wbr></wbr><span>Shuffle</span><wbr></wbr><span><span>Mode</span></span></span></span></a></div>
    </div>
    <div class="sideMenuPart" id="MediaPlayback-nav-submenu-1-11" pageId="MediaPlayback::com.apple.android.music.playback.model/PlaybackState///PointingToDeclaration//-357955546">
      <div class="overview"><a href="-media-playback/com.apple.android.music.playback.model/-playback-state/index.html"><span class="nav-link-grid"><span class="nav-link-child nav-icon annotation-class"></span><span class="nav-link-child"><span>Playback</span><wbr></wbr><span><span>State</span></span></span></span></a></div>
    </div>
    <div class="sideMenuPart" id="MediaPlayback-nav-submenu-1-12" pageId="MediaPlayback::com.apple.android.music.playback.model/PlayerMediaItem///PointingToDeclaration//-357955546">
      <div class="overview"><a href="-media-playback/com.apple.android.music.playback.model/-player-media-item/index.html"><span class="nav-link-grid"><span class="nav-link-child nav-icon interface"></span><span class="nav-link-child"><span>Player</span><wbr></wbr><span>Media</span><wbr></wbr><span><span>Item</span></span></span></span></a></div>
    </div>
    <div class="sideMenuPart" id="MediaPlayback-nav-submenu-1-13" pageId="MediaPlayback::com.apple.android.music.playback.model/PlayerQueueItem///PointingToDeclaration//-357955546">
      <div class="overview"><a href="-media-playback/com.apple.android.music.playback.model/-player-queue-item/index.html"><span class="nav-link-grid"><span class="nav-link-child nav-icon interface"></span><span class="nav-link-child"><span>Player</span><wbr></wbr><span>Queue</span><wbr></wbr><span><span>Item</span></span></span></span></a></div>
    </div>
    <div class="sideMenuPart" id="MediaPlayback-nav-submenu-1-14" pageId="MediaPlayback::com.apple.android.music.playback.model/RadioLikeState///PointingToDeclaration//-357955546">
      <div class="overview"><a href="-media-playback/com.apple.android.music.playback.model/-radio-like-state/index.html"><span class="nav-link-grid"><span class="nav-link-child nav-icon annotation-class"></span><span class="nav-link-child"><span>Radio</span><wbr></wbr><span>Like</span><wbr></wbr><span><span>State</span></span></span></span></a></div>
    </div>
  </div>
  <div class="sideMenuPart" id="MediaPlayback-nav-submenu-2" pageId="MediaPlayback::com.apple.android.music.playback.player////PointingToDeclaration//-357955546">
    <div class="overview"><span class="navButton" onclick="document.getElementById(&quot;MediaPlayback-nav-submenu-2&quot;).classList.toggle(&quot;hidden&quot;);"><span class="navButtonContent"></span></span><a href="-media-playback/com.apple.android.music.playback.player/index.html"><span>com.</span><wbr></wbr><span>apple.</span><wbr></wbr><span>android.</span><wbr></wbr><span>music.</span><wbr></wbr><span>playback.</span><wbr></wbr><span>player</span></a></div>
    <div class="sideMenuPart" id="MediaPlayback-nav-submenu-2-0" pageId="MediaPlayback::com.apple.android.music.playback.player/AudioCodec///PointingToDeclaration//-357955546">
      <div class="overview"><span class="navButton" onclick="document.getElementById(&quot;MediaPlayback-nav-submenu-2-0&quot;).classList.toggle(&quot;hidden&quot;);"><span class="navButtonContent"></span></span><a href="-media-playback/com.apple.android.music.playback.player/-audio-codec/index.html"><span class="nav-link-grid"><span class="nav-link-child nav-icon class-kt"></span><span class="nav-link-child"><span>Audio</span><wbr></wbr><span><span>Codec</span></span></span></span></a></div>
      <div class="sideMenuPart" id="MediaPlayback-nav-submenu-2-0-0" pageId="MediaPlayback::com.apple.android.music.playback.player/AudioCodec.Companion///PointingToDeclaration//-357955546">
        <div class="overview"><a href="-media-playback/com.apple.android.music.playback.player/-audio-codec/-companion/index.html"><span class="nav-link-grid"><span class="nav-link-child nav-icon object"></span><span class="nav-link-child"><span><span>Companion</span></span></span></span></a></div>
      </div>
    </div>
    <div class="sideMenuPart" id="MediaPlayback-nav-submenu-2-1" pageId="MediaPlayback::com.apple.android.music.playback.player/AudioConstants///PointingToDeclaration//-357955546">
      <div class="overview"><span class="navButton" onclick="document.getElementById(&quot;MediaPlayback-nav-submenu-2-1&quot;).classList.toggle(&quot;hidden&quot;);"><span class="navButtonContent"></span></span><a href="-media-playback/com.apple.android.music.playback.player/-audio-constants/index.html"><span class="nav-link-grid"><span class="nav-link-child nav-icon class-kt"></span><span class="nav-link-child"><span>Audio</span><wbr></wbr><span><span>Constants</span></span></span></span></a></div>
      <div class="sideMenuPart" id="MediaPlayback-nav-submenu-2-1-0" pageId="MediaPlayback::com.apple.android.music.playback.player/AudioConstants.Companion///PointingToDeclaration//-357955546">
        <div class="overview"><a href="-media-playback/com.apple.android.music.playback.player/-audio-constants/-companion/index.html"><span class="nav-link-grid"><span class="nav-link-child nav-icon object"></span><span class="nav-link-child"><span><span>Companion</span></span></span></span></a></div>
      </div>
    </div>
    <div class="sideMenuPart" id="MediaPlayback-nav-submenu-2-2" pageId="MediaPlayback::com.apple.android.music.playback.player/AudioVariantThreshold///PointingToDeclaration//-357955546">
      <div class="overview"><span class="navButton" onclick="document.getElementById(&quot;MediaPlayback-nav-submenu-2-2&quot;).classList.toggle(&quot;hidden&quot;);"><span class="navButtonContent"></span></span><a href="-media-playback/com.apple.android.music.playback.player/-audio-variant-threshold/index.html"><span class="nav-link-grid"><span class="nav-link-child nav-icon class-kt"></span><span class="nav-link-child"><span>Audio</span><wbr></wbr><span>Variant</span><wbr></wbr><span><span>Threshold</span></span></span></span></a></div>
      <div class="sideMenuPart" id="MediaPlayback-nav-submenu-2-2-0" pageId="MediaPlayback::com.apple.android.music.playback.player/AudioVariantThreshold.Companion///PointingToDeclaration//-357955546">
        <div class="overview"><a href="-media-playback/com.apple.android.music.playback.player/-audio-variant-threshold/-companion/index.html"><span class="nav-link-grid"><span class="nav-link-child nav-icon object"></span><span class="nav-link-child"><span><span>Companion</span></span></span></span></a></div>
      </div>
    </div>
  </div>
  <div class="sideMenuPart" id="MediaPlayback-nav-submenu-3" pageId="MediaPlayback::com.apple.android.music.playback.preferences////PointingToDeclaration//-357955546">
    <div class="overview"><span class="navButton" onclick="document.getElementById(&quot;MediaPlayback-nav-submenu-3&quot;).classList.toggle(&quot;hidden&quot;);"><span class="navButtonContent"></span></span><a href="-media-playback/com.apple.android.music.playback.preferences/index.html"><span>com.</span><wbr></wbr><span>apple.</span><wbr></wbr><span>android.</span><wbr></wbr><span>music.</span><wbr></wbr><span>playback.</span><wbr></wbr><span><span>preferences</span></span></a></div>
    <div class="sideMenuPart" id="MediaPlayback-nav-submenu-3-0" pageId="MediaPlayback::com.apple.android.music.playback.preferences/MediaPlaybackPreferences///PointingToDeclaration//-357955546">
      <div class="overview"><span class="navButton" onclick="document.getElementById(&quot;MediaPlayback-nav-submenu-3-0&quot;).classList.toggle(&quot;hidden&quot;);"><span class="navButtonContent"></span></span><a href="-media-playback/com.apple.android.music.playback.preferences/-media-playback-preferences/index.html"><span class="nav-link-grid"><span class="nav-link-child nav-icon class"></span><span class="nav-link-child"><span>Media</span><wbr></wbr><span>Playback</span><wbr></wbr><span><span>Preferences</span></span></span></span></a></div>
      <div class="sideMenuPart" id="MediaPlayback-nav-submenu-3-0-0" pageId="MediaPlayback::com.apple.android.music.playback.preferences/MediaPlaybackPreferences.FlavorSelection///PointingToDeclaration//-357955546">
        <div class="overview"><span class="navButton" onclick="document.getElementById(&quot;MediaPlayback-nav-submenu-3-0-0&quot;).classList.toggle(&quot;hidden&quot;);"><span class="navButtonContent"></span></span><a href="-media-playback/com.apple.android.music.playback.preferences/-media-playback-preferences/-flavor-selection/index.html"><span class="nav-link-grid"><span class="nav-link-child nav-icon enum-class"></span><span class="nav-link-child"><span>Flavor</span><wbr></wbr><span><span>Selection</span></span></span></span></a></div>
        <div class="sideMenuPart" id="MediaPlayback-nav-submenu-3-0-0-0" pageId="MediaPlayback::com.apple.android.music.playback.preferences/MediaPlaybackPreferences.FlavorSelection.DISABLED///PointingToDeclaration/{&quot;org.jetbrains.dokka.links.EnumEntryDRIExtra&quot;:{&quot;key&quot;:&quot;org.jetbrains.dokka.links.EnumEntryDRIExtra&quot;}}/-357955546">
          <div class="overview"><a href="-media-playback/com.apple.android.music.playback.preferences/-media-playback-preferences/-flavor-selection/-d-i-s-a-b-l-e-d/index.html"><span class="nav-link-grid"><span class="nav-link-child nav-icon enum-class-kt"></span><span class="nav-link-child"><span><span>DISABLED</span></span></span></span></a></div>
        </div>
        <div class="sideMenuPart" id="MediaPlayback-nav-submenu-3-0-0-1" pageId="MediaPlayback::com.apple.android.music.playback.preferences/MediaPlaybackPreferences.FlavorSelection.LOWHIGH///PointingToDeclaration/{&quot;org.jetbrains.dokka.links.EnumEntryDRIExtra&quot;:{&quot;key&quot;:&quot;org.jetbrains.dokka.links.EnumEntryDRIExtra&quot;}}/-357955546">
          <div class="overview"><a href="-media-playback/com.apple.android.music.playback.preferences/-media-playback-preferences/-flavor-selection/-l-o-w-h-i-g-h/index.html"><span class="nav-link-grid"><span class="nav-link-child nav-icon enum-class-kt"></span><span class="nav-link-child"><span><span>LOWHIGH</span></span></span></span></a></div>
        </div>
        <div class="sideMenuPart" id="MediaPlayback-nav-submenu-3-0-0-2" pageId="MediaPlayback::com.apple.android.music.playback.preferences/MediaPlaybackPreferences.FlavorSelection.RANDOM///PointingToDeclaration/{&quot;org.jetbrains.dokka.links.EnumEntryDRIExtra&quot;:{&quot;key&quot;:&quot;org.jetbrains.dokka.links.EnumEntryDRIExtra&quot;}}/-357955546">
          <div class="overview"><a href="-media-playback/com.apple.android.music.playback.preferences/-media-playback-preferences/-flavor-selection/-r-a-n-d-o-m/index.html"><span class="nav-link-grid"><span class="nav-link-child nav-icon enum-class-kt"></span><span class="nav-link-child"><span><span>RANDOM</span></span></span></span></a></div>
        </div>
      </div>
      <div class="sideMenuPart" id="MediaPlayback-nav-submenu-3-0-1" pageId="MediaPlayback::com.apple.android.music.playback.preferences/MediaPlaybackPreferences.Listener///PointingToDeclaration//-357955546">
        <div class="overview"><a href="-media-playback/com.apple.android.music.playback.preferences/-media-playback-preferences/-listener/index.html"><span class="nav-link-grid"><span class="nav-link-child nav-icon interface"></span><span class="nav-link-child"><span><span>Listener</span></span></span></span></a></div>
      </div>
    </div>
  </div>
  <div class="sideMenuPart" id="MediaPlayback-nav-submenu-4" pageId="MediaPlayback::com.apple.android.music.playback.queue////PointingToDeclaration//-357955546">
    <div class="overview"><span class="navButton" onclick="document.getElementById(&quot;MediaPlayback-nav-submenu-4&quot;).classList.toggle(&quot;hidden&quot;);"><span class="navButtonContent"></span></span><a href="-media-playback/com.apple.android.music.playback.queue/index.html"><span>com.</span><wbr></wbr><span>apple.</span><wbr></wbr><span>android.</span><wbr></wbr><span>music.</span><wbr></wbr><span>playback.</span><wbr></wbr><span>queue</span></a></div>
    <div class="sideMenuPart" id="MediaPlayback-nav-submenu-4-0" pageId="MediaPlayback::com.apple.android.music.playback.queue/CatalogPlaybackQueueItemProvider///PointingToDeclaration//-357955546">
      <div class="overview"><span class="navButton" onclick="document.getElementById(&quot;MediaPlayback-nav-submenu-4-0&quot;).classList.toggle(&quot;hidden&quot;);"><span class="navButtonContent"></span></span><a href="-media-playback/com.apple.android.music.playback.queue/-catalog-playback-queue-item-provider/index.html"><span class="nav-link-grid"><span class="nav-link-child nav-icon class"></span><span class="nav-link-child"><span>Catalog</span><wbr></wbr><span>Playback</span><wbr></wbr><span>Queue</span><wbr></wbr><span>Item</span><wbr></wbr><span><span>Provider</span></span></span></span></a></div>
      <div class="sideMenuPart" id="MediaPlayback-nav-submenu-4-0-0" pageId="MediaPlayback::com.apple.android.music.playback.queue/CatalogPlaybackQueueItemProvider.Builder///PointingToDeclaration//-357955546">
        <div class="overview"><a href="-media-playback/com.apple.android.music.playback.queue/-catalog-playback-queue-item-provider/-builder/index.html"><span class="nav-link-grid"><span class="nav-link-child nav-icon class"></span><span class="nav-link-child"><span><span>Builder</span></span></span></span></a></div>
      </div>
    </div>
    <div class="sideMenuPart" id="MediaPlayback-nav-submenu-4-1" pageId="MediaPlayback::com.apple.android.music.playback.queue/LibraryPlaybackQueueItemProvider///PointingToDeclaration//-357955546">
      <div class="overview"><span class="navButton" onclick="document.getElementById(&quot;MediaPlayback-nav-submenu-4-1&quot;).classList.toggle(&quot;hidden&quot;);"><span class="navButtonContent"></span></span><a href="-media-playback/com.apple.android.music.playback.queue/-library-playback-queue-item-provider/index.html"><span class="nav-link-grid"><span class="nav-link-child nav-icon class"></span><span class="nav-link-child"><span>Library</span><wbr></wbr><span>Playback</span><wbr></wbr><span>Queue</span><wbr></wbr><span>Item</span><wbr></wbr><span><span>Provider</span></span></span></span></a></div>
      <div class="sideMenuPart" id="MediaPlayback-nav-submenu-4-1-0" pageId="MediaPlayback::com.apple.android.music.playback.queue/LibraryPlaybackQueueItemProvider.Builder///PointingToDeclaration//-357955546">
        <div class="overview"><a href="-media-playback/com.apple.android.music.playback.queue/-library-playback-queue-item-provider/-builder/index.html"><span class="nav-link-grid"><span class="nav-link-child nav-icon class"></span><span class="nav-link-child"><span><span>Builder</span></span></span></span></a></div>
      </div>
    </div>
    <div class="sideMenuPart" id="MediaPlayback-nav-submenu-4-2" pageId="MediaPlayback::com.apple.android.music.playback.queue/PlaybackModeContainer///PointingToDeclaration//-357955546">
      <div class="overview"><a href="-media-playback/com.apple.android.music.playback.queue/-playback-mode-container/index.html"><span class="nav-link-grid"><span class="nav-link-child nav-icon class"></span><span class="nav-link-child"><span>Playback</span><wbr></wbr><span>Mode</span><wbr></wbr><span><span>Container</span></span></span></span></a></div>
    </div>
    <div class="sideMenuPart" id="MediaPlayback-nav-submenu-4-3" pageId="MediaPlayback::com.apple.android.music.playback.queue/PlaybackQueueInsertionType///PointingToDeclaration//-357955546">
      <div class="overview"><a href="-media-playback/com.apple.android.music.playback.queue/-playback-queue-insertion-type/index.html"><span class="nav-link-grid"><span class="nav-link-child nav-icon annotation-class"></span><span class="nav-link-child"><span>Playback</span><wbr></wbr><span>Queue</span><wbr></wbr><span>Insertion</span><wbr></wbr><span><span>Type</span></span></span></span></a></div>
    </div>
    <div class="sideMenuPart" id="MediaPlayback-nav-submenu-4-4" pageId="MediaPlayback::com.apple.android.music.playback.queue/PlaybackQueueItemProvider///PointingToDeclaration//-357955546">
      <div class="overview"><span class="navButton" onclick="document.getElementById(&quot;MediaPlayback-nav-submenu-4-4&quot;).classList.toggle(&quot;hidden&quot;);"><span class="navButtonContent"></span></span><a href="-media-playback/com.apple.android.music.playback.queue/-playback-queue-item-provider/index.html"><span class="nav-link-grid"><span class="nav-link-child nav-icon interface"></span><span class="nav-link-child"><span>Playback</span><wbr></wbr><span>Queue</span><wbr></wbr><span>Item</span><wbr></wbr><span><span>Provider</span></span></span></span></a></div>
      <div class="sideMenuPart" id="MediaPlayback-nav-submenu-4-4-0" pageId="MediaPlayback::com.apple.android.music.playback.queue/PlaybackQueueItemProvider.CancellationContext///PointingToDeclaration//-357955546">
        <div class="overview"><a href="-media-playback/com.apple.android.music.playback.queue/-playback-queue-item-provider/-cancellation-context/index.html"><span class="nav-link-grid"><span class="nav-link-child nav-icon interface"></span><span class="nav-link-child"><span>Cancellation</span><wbr></wbr><span><span>Context</span></span></span></span></a></div>
      </div>
      <div class="sideMenuPart" id="MediaPlayback-nav-submenu-4-4-1" pageId="MediaPlayback::com.apple.android.music.playback.queue/PlaybackQueueItemProvider.Listener///PointingToDeclaration//-357955546">
        <div class="overview"><span class="navButton" onclick="document.getElementById(&quot;MediaPlayback-nav-submenu-4-4-1&quot;).classList.toggle(&quot;hidden&quot;);"><span class="navButtonContent"></span></span><a href="-media-playback/com.apple.android.music.playback.queue/-playback-queue-item-provider/-listener/index.html"><span class="nav-link-grid"><span class="nav-link-child nav-icon interface"></span><span class="nav-link-child"><span><span>Listener</span></span></span></span></a></div>
        <div class="sideMenuPart" id="MediaPlayback-nav-submenu-4-4-1-0" pageId="MediaPlayback::com.apple.android.music.playback.queue/PlaybackQueueItemProvider.Listener.ItemsChangeType///PointingToDeclaration//-357955546">
          <div class="overview"><span class="navButton" onclick="document.getElementById(&quot;MediaPlayback-nav-submenu-4-4-1-0&quot;).classList.toggle(&quot;hidden&quot;);"><span class="navButtonContent"></span></span><a href="-media-playback/com.apple.android.music.playback.queue/-playback-queue-item-provider/-listener/-items-change-type/index.html"><span class="nav-link-grid"><span class="nav-link-child nav-icon enum-class"></span><span class="nav-link-child"><span>Items</span><wbr></wbr><span>Change</span><wbr></wbr><span><span>Type</span></span></span></span></a></div>
          <div class="sideMenuPart" id="MediaPlayback-nav-submenu-4-4-1-0-0" pageId="MediaPlayback::com.apple.android.music.playback.queue/PlaybackQueueItemProvider.Listener.ItemsChangeType.ItemChangeAdd///PointingToDeclaration/{&quot;org.jetbrains.dokka.links.EnumEntryDRIExtra&quot;:{&quot;key&quot;:&quot;org.jetbrains.dokka.links.EnumEntryDRIExtra&quot;}}/-357955546">
            <div class="overview"><a href="-media-playback/com.apple.android.music.playback.queue/-playback-queue-item-provider/-listener/-items-change-type/-item-change-add/index.html"><span class="nav-link-grid"><span class="nav-link-child nav-icon enum-class-kt"></span><span class="nav-link-child"><span>Item</span><wbr></wbr><span>Change</span><wbr></wbr><span><span>Add</span></span></span></span></a></div>
          </div>
          <div class="sideMenuPart" id="MediaPlayback-nav-submenu-4-4-1-0-1" pageId="MediaPlayback::com.apple.android.music.playback.queue/PlaybackQueueItemProvider.Listener.ItemsChangeType.ItemChangeRemove///PointingToDeclaration/{&quot;org.jetbrains.dokka.links.EnumEntryDRIExtra&quot;:{&quot;key&quot;:&quot;org.jetbrains.dokka.links.EnumEntryDRIExtra&quot;}}/-357955546">
            <div class="overview"><a href="-media-playback/com.apple.android.music.playback.queue/-playback-queue-item-provider/-listener/-items-change-type/-item-change-remove/index.html"><span class="nav-link-grid"><span class="nav-link-child nav-icon enum-class-kt"></span><span class="nav-link-child"><span>Item</span><wbr></wbr><span>Change</span><wbr></wbr><span><span>Remove</span></span></span></span></a></div>
          </div>
          <div class="sideMenuPart" id="MediaPlayback-nav-submenu-4-4-1-0-2" pageId="MediaPlayback::com.apple.android.music.playback.queue/PlaybackQueueItemProvider.Listener.ItemsChangeType.ItemChangeMove///PointingToDeclaration/{&quot;org.jetbrains.dokka.links.EnumEntryDRIExtra&quot;:{&quot;key&quot;:&quot;org.jetbrains.dokka.links.EnumEntryDRIExtra&quot;}}/-357955546">
            <div class="overview"><a href="-media-playback/com.apple.android.music.playback.queue/-playback-queue-item-provider/-listener/-items-change-type/-item-change-move/index.html"><span class="nav-link-grid"><span class="nav-link-child nav-icon enum-class-kt"></span><span class="nav-link-child"><span>Item</span><wbr></wbr><span>Change</span><wbr></wbr><span><span>Move</span></span></span></span></a></div>
          </div>
          <div class="sideMenuPart" id="MediaPlayback-nav-submenu-4-4-1-0-3" pageId="MediaPlayback::com.apple.android.music.playback.queue/PlaybackQueueItemProvider.Listener.ItemsChangeType.ItemChangeUpdate///PointingToDeclaration/{&quot;org.jetbrains.dokka.links.EnumEntryDRIExtra&quot;:{&quot;key&quot;:&quot;org.jetbrains.dokka.links.EnumEntryDRIExtra&quot;}}/-357955546">
            <div class="overview"><a href="-media-playback/com.apple.android.music.playback.queue/-playback-queue-item-provider/-listener/-items-change-type/-item-change-update/index.html"><span class="nav-link-grid"><span class="nav-link-child nav-icon enum-class-kt"></span><span class="nav-link-child"><span>Item</span><wbr></wbr><span>Change</span><wbr></wbr><span><span>Update</span></span></span></span></a></div>
          </div>
        </div>
        <div class="sideMenuPart" id="MediaPlayback-nav-submenu-4-4-1-1" pageId="MediaPlayback::com.apple.android.music.playback.queue/PlaybackQueueItemProvider.Listener.ProviderItemsUpdate///PointingToDeclaration//-357955546">
          <div class="overview"><a href="-media-playback/com.apple.android.music.playback.queue/-playback-queue-item-provider/-listener/-provider-items-update/index.html"><span class="nav-link-grid"><span class="nav-link-child nav-icon class"></span><span class="nav-link-child"><span>Provider</span><wbr></wbr><span>Items</span><wbr></wbr><span><span>Update</span></span></span></span></a></div>
        </div>
      </div>
    </div>
    <div class="sideMenuPart" id="MediaPlayback-nav-submenu-4-5" pageId="MediaPlayback::com.apple.android.music.playback.queue/PlaybackQueueItemsAdded///PointingToDeclaration//-357955546">
      <div class="overview"><span class="navButton" onclick="document.getElementById(&quot;MediaPlayback-nav-submenu-4-5&quot;).classList.toggle(&quot;hidden&quot;);"><span class="navButtonContent"></span></span><a href="-media-playback/com.apple.android.music.playback.queue/-playback-queue-items-added/index.html"><span class="nav-link-grid"><span class="nav-link-child nav-icon class"></span><span class="nav-link-child"><span>Playback</span><wbr></wbr><span>Queue</span><wbr></wbr><span>Items</span><wbr></wbr><span><span>Added</span></span></span></span></a></div>
      <div class="sideMenuPart" id="MediaPlayback-nav-submenu-4-5-0" pageId="MediaPlayback::com.apple.android.music.playback.queue/PlaybackQueueItemsAdded.Builder///PointingToDeclaration//-357955546">
        <div class="overview"><a href="-media-playback/com.apple.android.music.playback.queue/-playback-queue-items-added/-builder/index.html"><span class="nav-link-grid"><span class="nav-link-child nav-icon class"></span><span class="nav-link-child"><span><span>Builder</span></span></span></span></a></div>
      </div>
    </div>
    <div class="sideMenuPart" id="MediaPlayback-nav-submenu-4-6" pageId="MediaPlayback::com.apple.android.music.playback.queue/StationPlaybackQueueItemProvider///PointingToDeclaration//-357955546">
      <div class="overview"><span class="navButton" onclick="document.getElementById(&quot;MediaPlayback-nav-submenu-4-6&quot;).classList.toggle(&quot;hidden&quot;);"><span class="navButtonContent"></span></span><a href="-media-playback/com.apple.android.music.playback.queue/-station-playback-queue-item-provider/index.html"><span class="nav-link-grid"><span class="nav-link-child nav-icon class-kt"></span><span class="nav-link-child"><span>Station</span><wbr></wbr><span>Playback</span><wbr></wbr><span>Queue</span><wbr></wbr><span>Item</span><wbr></wbr><span><span>Provider</span></span></span></span></a></div>
      <div class="sideMenuPart" id="MediaPlayback-nav-submenu-4-6-0" pageId="MediaPlayback::com.apple.android.music.playback.queue/StationPlaybackQueueItemProvider.Builder///PointingToDeclaration//-357955546">
        <div class="overview"><a href="-media-playback/com.apple.android.music.playback.queue/-station-playback-queue-item-provider/-builder/index.html"><span class="nav-link-grid"><span class="nav-link-child nav-icon class-kt"></span><span class="nav-link-child"><span><span>Builder</span></span></span></span></a></div>
      </div>
      <div class="sideMenuPart" id="MediaPlayback-nav-submenu-4-6-1" pageId="MediaPlayback::com.apple.android.music.playback.queue/StationPlaybackQueueItemProvider.CREATOR///PointingToDeclaration//-357955546">
        <div class="overview"><a href="-media-playback/com.apple.android.music.playback.queue/-station-playback-queue-item-provider/-c-r-e-a-t-o-r/index.html"><span class="nav-link-grid"><span class="nav-link-child nav-icon object"></span><span class="nav-link-child"><span><span>CREATOR</span></span></span></span></a></div>
      </div>
    </div>
  </div>
</div>

`;
/*
 * Copyright 2014-2023 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license.
 */

navigationPageText = Promise.resolve(__dokkaNavigation)

displayNavigationFromPage = () => {
    navigationPageText.then(data => {
        document.getElementById("sideMenu").innerHTML = data;
    }).then(() => {
        document.querySelectorAll(".overview > a").forEach(link => {
            link.setAttribute("href", pathToRoot + link.getAttribute("href"));
        })
    }).then(() => {
        document.querySelectorAll(".sideMenuPart").forEach(nav => {
            if (!nav.classList.contains("hidden"))
                nav.classList.add("hidden")
        })
    }).then(() => {
        revealNavigationForCurrentPage()
    }).then(() => {
        scrollNavigationToSelectedElement()
    })
    document.querySelectorAll('.footer a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            document.querySelector(this.getAttribute('href')).scrollIntoView({
                behavior: 'smooth'
            });
        });
    });
}

revealNavigationForCurrentPage = () => {
    let pageId = document.getElementById("content").attributes["pageIds"].value.toString();
    let parts = document.querySelectorAll(".sideMenuPart");
    let found = 0;
    do {
        parts.forEach(part => {
            if (part.attributes['pageId'].value.indexOf(pageId) !== -1 && found === 0) {
                found = 1;
                if (part.classList.contains("hidden")) {
                    part.classList.remove("hidden");
                    part.setAttribute('data-active', "");
                }
                revealParents(part)
            }
        });
        pageId = pageId.substring(0, pageId.lastIndexOf("/"))
    } while (pageId.indexOf("/") !== -1 && found === 0)
};
revealParents = (part) => {
    if (part.classList.contains("sideMenuPart")) {
        if (part.classList.contains("hidden"))
            part.classList.remove("hidden");
        revealParents(part.parentNode)
    }
};

scrollNavigationToSelectedElement = () => {
    let selectedElement = document.querySelector('div.sideMenuPart[data-active]')
    if (selectedElement == null) { // nothing selected, probably just the main page opened
        return
    }

    let hasIcon = selectedElement.querySelectorAll(":scope > div.overview span.nav-icon").length > 0

    // for instance enums also have children and are expandable, but are not package/module elements
    let isPackageElement = selectedElement.children.length > 1 && !hasIcon
    if (isPackageElement) {
        // if package is selected or linked, it makes sense to align it to top
        // so that you can see all the members it contains
        selectedElement.scrollIntoView(true)
    } else {
        // if a member within a package is linked, it makes sense to center it since it,
        // this should make it easier to look at surrounding members
        selectedElement.scrollIntoView({
            behavior: 'auto',
            block: 'center',
            inline: 'center'
        })
    }
}

/*
    This is a work-around for safari being IE of our times.
    It doesn't fire a DOMContentLoaded, presumabely because eventListener is added after it wants to do it
*/
if (document.readyState == 'loading') {
    window.addEventListener('DOMContentLoaded', () => {
        displayNavigationFromPage()
    })
} else {
    displayNavigationFromPage()
}
