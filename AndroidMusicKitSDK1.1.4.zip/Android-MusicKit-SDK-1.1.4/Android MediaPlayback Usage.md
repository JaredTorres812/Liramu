# MusicKit for Android - MediaPlayback API

## Overview

The MediaPlayback SDK gives your app the ability to play Apple Music catalog
and library content. It handles streaming, decryption, audio decoding, queue
management, and play activity reporting. Your app controls playback through
the `MediaPlayerController` interface and receives state updates via a
listener pattern.

## Prerequisites

- A working MusicKitAuth integration (see "Android MusicKitAuth Usage")
- A valid Developer Token and Music User Token
- A `TokenProvider` implementation that supplies both tokens

## Architecture

    ┌──────────────────────────────────────────────────────┐
    │                      Your App                        │
    │                                                      │
    │  ┌──────────────┐    ┌───────────────────────────┐   │
    │  │ TokenProvider│    │ MediaPlayerController     │   │
    │  │ (your impl)  │───>│  .prepare()               │   │
    │  └──────────────┘    │  .play() / .pause()       │   │
    │                      │  .skipToNextItem()        │   │
    │         ┌────────────│  .addListener(...)        │   │
    │         │            └───────────────────────────┘   │
    │         │ callbacks                                  │
    │         ▼                                            │
    │  ┌───────────────────────────────────────────────┐   │
    │  │ MediaPlayerController.Listener                │   │
    │  │  onPlaybackStateChanged(...)                  │   │
    │  │  onCurrentItemChanged(...)                    │   │
    │  │  onPlaybackQueueChanged(...)                  │   │
    │  │  onPlaybackError(...)                         │   │
    │  │  ... (13 callbacks total)                     │   │
    │  └───────────────────────────────────────────────┘   │
    └──────────────────────────────────────────────────────┘

## Creating a MediaPlayerController

The controller is your single interface to playback. Create it with
your `TokenProvider`:

    MediaPlayerController player = MediaPlayerControllerFactory.createLocalController(context, tokenProvider);

There is also an overload that accepts a `Handler` for controlling which
thread receives listener callbacks:

    Handler mainHandler = new Handler(Looper.getMainLooper());
    MediaPlayerController player = MediaPlayerControllerFactory
        .createLocalController(context, mainHandler, tokenProvider);

Create the controller once and reuse it for the lifetime of your playback
session.

## Populating the Playback Queue

Before playing music, you must tell the controller what to play by creating
a `PlaybackQueueItemProvider`. The SDK provides three provider types for
different content sources.

Songs use their catalog or library ID, while albums, playlists, and stations 
use their container ID.

### Catalog Content

For content from the Apple Music catalog (songs and albums the user does
not own but can stream with a subscription):

    CatalogPlaybackQueueItemProvider.Builder builder =
        new CatalogPlaybackQueueItemProvider.Builder();

    // Play an album by its adam ID
    builder.containers(MediaContainerType.ALBUM, "310730204");

    // Or play specific songs from a container
    builder.items(MediaItemType.SONG,
        MediaContainerType.ALBUM,     // container type
        "310730204",                   // container ID
        "310730210", "310730211");     // song IDs

    // Or play a playlist
    builder.containers(MediaContainerType.PLAYLIST, "pl.abc123");
    builder.playlistVersionHash("v1hash");  // enables queue diffing

    // Configure playback start point
    builder.startItemIndex(3);                          
    builder.shuffleMode(PlaybackShuffleMode.SHUFFLE_MODE_OFF);
    builder.featureName("browse_album_detail");         // analytics breadcrumb

    player.prepare(builder.build(), true);  // true = start playing immediately

### Library Content

For content from the user's personal library (purchased or added songs):

    LibraryPlaybackQueueItemProvider.Builder builder =
        new LibraryPlaybackQueueItemProvider.Builder();

    // Same API shape as CatalogPlaybackQueueItemProvider
    builder.items(MediaItemType.SONG, "i.library123", "i.library456");
    builder.containers(MediaContainerType.PLAYLIST, "p.playlistId");
    builder.startItemIndex(0);
    builder.shuffleMode(PlaybackShuffleMode.SHUFFLE_MODE_OFF);
    builder.featureName("library_songs");

    player.prepare(builder.build(), true);

### Radio Stations

Apple Music has two kinds of radio stations:

- **Track-based stations** — curated or algorithmic playlists that serve discrete
  tracks (e.g. genre stations, personal stations). The queue behaves like a
  normal playlist: tracks have durations, skip works, and the queue is editable.
- **Live radio stations** — continuous broadcast streams (Apple Music 1, Apple
  Music Hits, etc.). There is a single stream rather than individual tracks,
  skip/seek are disabled, the queue is not editable, and track metadata updates
  mid-stream via `onMetadataUpdated` as the station rotates content.

The MediaPlayback SDK does not provide station discovery or a hardcoded list of stations,
you must query for the station IDs and whether the station is live or track-based through media API 

#### Track-based stations

    StationPlaybackQueueItemProvider.Builder builder = new StationPlaybackQueueItemProvider.Builder();

    builder.containers(MediaContainerType.RADIO_STATION, "ra.stationId");
    builder.stationHash("hashValue");
    builder.playActivityFeatureName("radio_detail");

    player.prepare(builder.build(), true);

#### Live radio stations

For live radio, you must set `isLiveRadio(true)` on the builder for the correct playback behavior

    StationPlaybackQueueItemProvider.Builder builder = new StationPlaybackQueueItemProvider.Builder();

    builder.containers(MediaContainerType.RADIO_STATION, "ra.978194965");
    builder.isLiveRadio(true);
    builder.title("Apple Music 1");
    builder.stationHash("hashValue");
    builder.playActivityFeatureName("radio_live");

    player.prepare(builder.build(), true);

During live radio playback:

- `player.isLiveStream()` returns `true`
- `player.getDuration()` returns `DURATION_UNKNOWN`
- `player.canSkipToNextItem()` and `canSeek()` return `false`
- `onMetadataUpdated` fires when the currently playing song changes on air
- `currentItem.getItem().isLiveRadio()` returns `true`

### Preparing with Insertion Types

For the initial play action, use the two-argument `prepare()`:

    player.prepare(provider, true);   // true = auto-play when ready
    player.prepare(provider, false);  // false = load but stay paused

For adding to an existing queue (e.g. "Play Next" or "Play Later"), use
`addQueueItems` with an insertion type:

    player.addQueueItems(provider, PlaybackQueueInsertionType.INSERTION_TYPE_AFTER_CURRENT_ITEM);

The available insertion types are:

| Constant                                  | Behavior                                              |
|-------------------------------------------|-------------------------------------------------------|
| `INSERTION_TYPE_CLEAR_AND_REPLACE`        | Clear the queue and load the new content               |
| `INSERTION_TYPE_AFTER_CURRENT_ITEM`       | Insert after the currently playing track ("Play Next") |
| `INSERTION_TYPE_AT_END`                   | Append to the end of the queue ("Play Later")          |
| `INSERTION_TYPE_AT_END_OF_QUEUE_SECTION`  | Append to the "queue section" (user-added tracks)      |

Use `player.canAddToQueueSection()` to check whether the queue section
feature is available before using `INSERTION_TYPE_AT_END_OF_QUEUE_SECTION`.
You can fall back to `INSERTION_TYPE_AT_END` when it is not available.

## Controlling Playback

    player.play();                    // Start or resume playback
    player.pause();                   // Pause playback
    player.stop();                    // Stop playback and release audio focus
    player.seekToPosition(30_000L);   // Seek to 30 seconds from start (millis)

    player.skipToNextItem();          // Skip forward in queue
    player.skipToPreviousItem();      // Skip backward in queue
    player.skipToQueueItemWithId(id); // Jump to a specific queue item by ID

    player.setRepeatMode(PlaybackRepeatMode.REPEAT_MODE_ALL);
    player.setShuffleMode(PlaybackShuffleMode.SHUFFLE_MODE_SONGS);

### Queue Editing

Queue operations use playback queue IDs, which are assigned by the SDK
when tracks are loaded. You obtain them from `PlayerQueueItem` objects
returned by listener callbacks and controller methods:

    // Get the current track's queue ID
    long currentId = player.getCurrentItem().getPlaybackQueueId();

    // Get queue IDs for upcoming tracks
    for (PlayerQueueItem item : player.getQueueItems()) {
        long queueId = item.getPlaybackQueueId();
    }

    // Or populate them from onPlaybackQueueChanged / onCurrentItemChanged callbacks

    player.removeQueueItemWithId(playbackQueueId);

    // Move a track relative to another
    player.moveQueueItemWithId(
        sourcePlaybackQueueId,
        targetPlaybackQueueId,
        PlaybackQueueMoveTargetType.MOVE_AFTER_TARGET
    );

    // Clear the user-added "queue section"
    player.clearQueueSection();

### Checking Allowed Actions

The controller reports what actions are valid in the current state. Use
these to enable or disable UI controls. The player ignores calls to
disallowed actions.

    player.canSkipToNextItem();       // Can skip forward?
    player.canSkipToPreviousItem();   // Can skip backward?
    player.canSeek();                 // Can seek in current track?
    player.canSetRepeatMode();        // Can change repeat mode?
    player.canSetShuffleMode();       // Can change shuffle mode?
    player.canAddToQueueSection();    // Can add to "queue section"?

## Listening for State Changes

All controller methods that modify playback state are asynchronous. Register
a listener to receive callbacks when state changes:

    player.addListener(listener);
    player.removeListener(listener);

The listener interface has 13 callbacks. You must implement all of them,
methods you don't care about can have empty bodies.

### Core Playback Callbacks

    @Override
    public void onPlaybackStateChanged(
            MediaPlayerController controller,
            @PlaybackState int previousState,
            @PlaybackState int currentState) {
        // Fires on playback transitions. PlaybackState: STOPPED, PLAYING, PAUSED.
    }

    @Override
    public void onPlaybackStateUpdated(MediaPlayerController controller) {
        // Fires periodically with updated position/duration.
    }

    @Override
    public void onBufferingStateChanged(
            MediaPlayerController controller,
            boolean isBuffering) {
        // Fires when buffering starts or stops.
    }

### Track Change Callbacks

    @Override
    public void onCurrentItemChanged(
            MediaPlayerController controller,
            PlayerQueueItem previousItem,
            PlayerQueueItem currentItem) {
        // Fires when the playing track changes (skip, queue load, natural end).
    }

    @Override
    public void onItemEnded(
            MediaPlayerController controller,
            PlayerQueueItem queueItem,
            long position) {
        // Fires when a track finishes playing naturally. position is in millis.
    }

    @Override
    public void onMetadataUpdated(
            MediaPlayerController controller,
            PlayerQueueItem currentItem) {
        // Fires when metadata for the current item changes (e.g. live radio).
    }

### Queue Callbacks

    @Override
    public void onPlaybackQueueChanged(
            MediaPlayerController controller,
            List<PlayerQueueItem> queueItems) {
        // Fires when the queue contents change (new queue loaded,
        // items added/removed/reordered).
        // queueItems contains the upcoming tracks after the current one.
    }

    @Override
    public void onPlaybackQueueItemsAdded(
            MediaPlayerController controller,
            PlaybackQueueItemsAdded addedItems) {
        // Fires specifically when items are inserted into the queue.
        // Distinct from onPlaybackQueueChanged -- use this for "added to queue"
        // confirmation UI.
    }

### Mode Change Callbacks

    @Override
    public void onPlaybackModeChanged(
            MediaPlayerController controller,
            PlaybackModeContainer playbackMode) {
        // Fires when shuffle, repeat, or continuous playback modes change.
        // PlaybackModeContainer has: didShuffleModeChange(),
        // didRepeatModeChanged(), getRepeatMode(), getShuffleMode()
    }

    @Override
    public void onPlaybackRepeatModeChanged(
            MediaPlayerController controller,
            @PlaybackRepeatMode int currentRepeatMode) {
        // Fires when repeat mode changes.
        // Values: REPEAT_MODE_OFF, REPEAT_MODE_ONE, REPEAT_MODE_ALL
    }

    @Override
    public void onPlaybackShuffleModeChanged(
            MediaPlayerController controller,
            @PlaybackShuffleMode int currentShuffleMode) {
        // Fires when shuffle mode changes.
        // Values: SHUFFLE_MODE_OFF, SHUFFLE_MODE_SONGS
    }

### State Restoration

    @Override
    public void onPlayerStateRestored(MediaPlayerController controller) {
        // Fires after restoreState() successfully loads a previously saved
        // playback session (queue position, track, playhead).
    }

Call `restoreState` to reload the player's last session:

    player.restoreState(/* startPlaying = */ false, /* seekToSavedPosition = */ false);

## Reading Player State

Query the controller for current playback information at any time:

    // Playback position (milliseconds)
    long position = player.getCurrentPosition();
    long buffered = player.getBufferedPosition();
    long duration = player.getDuration();

    int state = player.getPlaybackState();  // STOPPED, PLAYING, or PAUSED
    boolean buffering = player.isBuffering();

    // Queue
    int index = player.getPlaybackQueueIndex();
    int count = player.getPlaybackQueueItemCount();
    List<PlayerQueueItem> upcoming = player.getQueueItems();

    int repeat = player.getRepeatMode();
    int shuffle = player.getShuffleMode();
    int audioVariant = player.getAudioVariant();

## Reading Track Metadata

Track metadata is available through `PlayerQueueItem` and `PlayerMediaItem`:

    PlayerQueueItem queueItem = player.getCurrentItem();
    long queueId = queueItem.getPlaybackQueueId();  // unique ID for queue ops
    boolean inQueueSection = queueItem.isInQueueSection();  

    PlayerMediaItem item = queueItem.getItem();
    item.getTitle();                   // "Iron Man"
    item.getArtistName();              // "Black Sabbath"
    item.getAlbumTitle();              // "Paranoid"
    item.isExplicitContent();          // false
    item.isLiveRadio();                // false

    See Javadoc for full list

### Dolby Atmos

    These are protected so some developer tokens
    won't have access to these encoded assets and therefore won't be vended down by the server
    regardless of preferences

    // Read current state
    String state = prefs.getDolbyAtmosState();  // "AUTOMATIC", "ALWAYS_ON", or "OFF"

    // Set state
    prefs.setDolbyAtmosState(DolbyAtmosState.ALWAYS_ON);
    prefs.setDolbyAtmosState(DolbyAtmosState.OFF);

### Lossless Audio

    boolean lossless = prefs.isLosslessEnabled();
    prefs.setLosslessEnabled(true);

    // Per-network quality (returns AudioQuality enum name as String)
    String cellularQuality = prefs.getCellularAudioQuality();
    String wifiQuality = prefs.getWifiAudioQuality();

    // AudioQuality values: HIGH_EFFICIENCY, HIGH_QUALITY, LOSSLESS, HIGH_RES_LOSSLESS
    // When lossless is disabled, quality is capped at HIGH_QUALITY automatically.

### Detecting Current Audio Variant

During playback, `player.getAudioVariant()` returns which audio format
the current track is actually streaming in:

    int variant = player.getAudioVariant();

| Constant                                        | Meaning                      |
|-------------------------------------------------|------------------------------|
| `AudioConstants.TRACK_VARIANTS_UNKNOWN`         | Not yet determined           |
| `AudioConstants.TRACK_VARIANTS_AAC_STEREO`      | Standard quality AAC         |
| `AudioConstants.TRACK_VARIANTS_AAC_STEREO_HIGH_QUALITY` | High quality AAC      |
| `AudioConstants.TRACK_VARIANTS_LOSSLESS`        | Lossless (ALAC, up to 48kHz) |
| `AudioConstants.TRACK_VARIANTS_HI_RES_LOSSLESS` | Hi-Res Lossless (up to 192kHz) |
| `AudioConstants.TRACK_VARIANTS_DOLBY_ATMOS`     | Dolby Atmos spatial audio    |

## Error Handling

All playback errors arrive through the `onPlaybackError` listener callback
as a `MediaPlayerException`. The exception's `getType()` method indicates the
error category, and `getCause()` often contains a more specific exception.

    @Override
    public void onPlaybackError(
            MediaPlayerController controller,
            MediaPlayerException exception) {

        switch (exception.getType()) {
            case MediaPlayerException.TYPE_IO:
                // Transient network/IO error. SDK retries automatically 
                break;
            case MediaPlayerException.TYPE_DRM:
                // DRM/decryption failure. Not recoverable in-app; surface an error.
                break;
            case MediaPlayerException.TYPE_PLAYBACK_QUEUE:
                // Queue load/resolution error. Surface to UI; let the user re-queue.
                // exception.getCause() has the underlying queue error.
                break;
            case MediaPlayerException.TYPE_PLAYBACK_LEASE:
                // Another device took over. SDK has already stopped playback.
                // Show a "playing on another device" state; do not auto-retry.
                break;
            case MediaPlayerException.TYPE_USER_SUBSCRIPTION_INVALID:
                // Subscription expired/revoked. SDK has already stopped playback.
                // Prompt the user to resubscribe, then call
                // player.getPlaybackStoreConfiguration().notifySubscriptionChanged().
                break;
            case MediaPlayerException.TYPE_MUSIC_USER_TOKEN_ERROR:
                // MUT expired or invalid. SDK has already stopped playback.
                // Call AuthenticationManager.refreshTokenAsync(); on success call
                // notifyTokenChanged(). On refresh failure, terminate the session.
                break;
            case MediaPlayerException.TYPE_EXPLICIT_VERIFY_AGE:
                // Explicit content on an age-restricted account. Show an
                // age-verification prompt. The offending item ID is in
                // exception.getExtraParams() under PlayerConstants.KEY_ITEMID.
                break;
        }
    }

The SDK automatically stops playback for subscription, token, and lease
errors. Your `onPlaybackError` handler only needs to update UI and
initiate recovery (e.g. prompt resubscription or call `refreshTokenAsync`).


## Responding to Token Changes

When tokens are refreshed, notify the playback controller so it can
update its internal authorization state:

    // After a successful token refresh
    player.getPlaybackStoreConfiguration().notifyTokenChanged(context, tokenProvider);

    // After a subscription status change
    player.getPlaybackStoreConfiguration().notifySubscriptionChanged();

### Terminating Session

To terminate a session and clear the current user's info:

1. Clear your `TokenProvider`'s storage so its getters return
   `null`:

        tokenStorage.clear();

2. Stop playback and tear down the foreground surface:

        player.pause();
        player.stop();
        mediaSession.setActive(false);
        mediaSession.release();
        notificationManager.cancel();
        stopForeground(STOP_FOREGROUND_REMOVE);

3. Push the cleared values into the SDK. `notifyTokenChanged` reads
   the current `TokenProvider` state — passing a provider whose getters
   now return `null` clears the SDK's own token cache:

        player.getPlaybackStoreConfiguration()
              .notifyTokenChanged(context, tokenProvider);

4. Drop the SDK's persisted queue and cached playback state:

        MediaPlayerContextFactory.createPlayerContext(context).clearData();

### Sourcing the MUT from elsewhere

`TokenProvider` is source-agnostic. If the MUT comes from outside
MusicKitAuth (e.g. link.apple.com), skip
`createIntentBuilder`/`handleTokenResult` and send the MUT in
directly: update your `TokenProvider` storage, then call

    player.getPlaybackStoreConfiguration()
          .notifyTokenChanged(context, tokenProvider);

## Cleaning Up Resources

When the owning Activity or Service is torn down, release the
controller. 

    player.removeListener(listener);
    player.release();

## Complete Example

    public class PlaybackActivity extends AppCompatActivity
            implements MediaPlayerController.Listener {

        private MediaPlayerController player;
        private MyTokenProvider tokenProvider;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_playback);

            tokenProvider = new MyTokenProvider(this);

            player = MediaPlayerControllerFactory
                .createLocalController(this, tokenProvider);
            player.addListener(this);

            // Restore previous session if any
            player.restoreState(false, false);
        }

        // --- Playing content ---

        void playAlbum(String albumId) {
            CatalogPlaybackQueueItemProvider.Builder builder =
                new CatalogPlaybackQueueItemProvider.Builder();
            builder.containers(MediaContainerType.ALBUM, albumId);
            player.prepare(builder.build(), true);
        }

        void playNext(String songId) {
            CatalogPlaybackQueueItemProvider.Builder builder =
                new CatalogPlaybackQueueItemProvider.Builder();
            builder.items(MediaItemType.SONG, songId);
            player.addQueueItems(builder.build(),
                PlaybackQueueInsertionType.INSERTION_TYPE_AFTER_CURRENT_ITEM);
        }

        // --- Listener callbacks ---

        @Override
        public void onPlaybackStateChanged(
                MediaPlayerController c, int prev, int curr) {
            runOnUiThread(() -> {
                switch (curr) {
                    case PlaybackState.PLAYING:
                        showPauseButton();
                        break;
                    case PlaybackState.PAUSED:
                        showPlayButton();
                        break;
                    case PlaybackState.STOPPED:
                        showPlayButton();
                        resetSeekBar();
                        break;
                }
            });
        }

        @Override
        public void onCurrentItemChanged(
                MediaPlayerController c,
                PlayerQueueItem prev,
                PlayerQueueItem curr) {
            if (curr == null) return;
            runOnUiThread(() -> {
                PlayerMediaItem item = curr.getItem();
                updateTrackTitle(item.getTitle());
                updateArtistName(item.getArtistName());
                updateAlbumArt(item.getArtworkUrl(600, 600));
                updateDuration(item.getDuration());
            });
        }

        @Override
        public void onPlaybackStateUpdated(MediaPlayerController c) {
            runOnUiThread(() -> {
                updateSeekBar(c.getCurrentPosition(), c.getDuration());
            });
        }

        @Override
        public void onPlaybackError(
                MediaPlayerController c, MediaPlayerException ex) {
            switch (ex.getType()) {
                case MediaPlayerException.TYPE_MUSIC_USER_TOKEN_ERROR:
                    refreshToken();
                    break;
                case MediaPlayerException.TYPE_USER_SUBSCRIPTION_INVALID:
                    showSubscriptionExpiredDialog();
                    break;
                case MediaPlayerException.TYPE_PLAYBACK_LEASE:
                    showPlaybackLeaseDialog();
                    break;
            }
        }

        // --- Token management ---

        private void refreshToken() {
            AuthenticationManager auth =
                AuthenticationFactory.createAuthenticationManager(this);
            auth.refreshTokenAsync(tokenProvider, new TokenRefreshListener() {
                @Override
                public void onTokenRefreshed(String mut) {
                    tokenProvider.storeNewMut(mut);
                    player.getPlaybackStoreConfiguration()
                        .notifyTokenChanged(PlaybackActivity.this, tokenProvider);
                }

                @Override
                public void onTokenError(TokenError error) {
                    // Require re-authentication
                    promptReauthentication();
                }
            });
        }

        // --- Cleanup ---

        @Override
        protected void onDestroy() {
            if (player != null) {
                player.removeListener(this);
                player.release();
            }
            super.onDestroy();
        }

        // --- Remaining listener callbacks (implement as needed) ---

        @Override public void onBufferingStateChanged(MediaPlayerController c, boolean b) {}
        @Override public void onItemEnded(MediaPlayerController c, PlayerQueueItem q, long p) {}
        @Override public void onMetadataUpdated(MediaPlayerController c, PlayerQueueItem q) {}
        @Override public void onPlaybackQueueChanged(MediaPlayerController c, List<PlayerQueueItem> q) {}
        @Override public void onPlaybackQueueItemsAdded(MediaPlayerController c, PlaybackQueueItemsAdded a) {}
        @Override public void onPlaybackModeChanged(MediaPlayerController c, PlaybackModeContainer m) {}
        @Override public void onPlaybackRepeatModeChanged(MediaPlayerController c, int mode) {}
        @Override public void onPlaybackShuffleModeChanged(MediaPlayerController c, int mode) {}
        @Override public void onPlayerStateRestored(MediaPlayerController c) {}
    }