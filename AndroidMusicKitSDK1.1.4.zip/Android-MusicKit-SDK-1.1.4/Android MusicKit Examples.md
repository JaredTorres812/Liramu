# MusicKit for Android - Playback API

## Creating A MediaPlayerController

Before starting a playback session, you must first create a `MediaPlayerController` instance. This will be your interface to all things playback-related, and can be used for the duration of a playback session.

    import com.apple.android.music.playback.controller.MediaPlayerController;
    import com.apple.android.music.playback.controller.MediaPlayerControllerFactory;
    
    TokenProvider tokenProvider = new TokenProvider() {
    
        @Override
        public String getDeveloperToken() {
            return developerToken;
        }
        
        @Override
        public String getUserToken() {
            return userToken;
        }
    
    };
    MediaPlayerController playerController = MediaPlayerControllerFactory.createLocalController(context, tokenProvider);

## Populating The Playback Queue

Once you have a `MediaPlayerController`, you will need to tell it what you would like to play. This is done by creating an instance of a `PlaybackQueueItemProvider`, and passing it to the player controller for playback. Currently, a playback queue can be populated using string identifiers from the Apple Music catalog. These identifiers can be retreived using the Apple Music API REST endpoints for catalog items. The following example shows how to populate the playback queue with an album from the catalog, and start playback once it is ready.


    import com.apple.android.music.playback.controller.MediaPlayerController;
    import com.apple.android.music.playback.queue.CatalogPlaybackQueueItemProvider;
    
    MediaPlayerController playerController;

    CatalogPlaybackQueueItemProvider.Builder queueProviderBuilder = new CatalogPlaybackQueueItemProvider.Builder();
    builder.containers(MediaContainerType.ALBUM, "310730204");
    
    playerController.prepare(queueProviderBuilder.build(), true);

## Controlling Playback

A `MediaPlayerController` instance provides several methods for controlling playback. Below are a few common uses:

    import com.apple.android.music.playback.controller.MediaPlayerController;
    
    MediaPlayerController playerController;
    
    playerController.pause();                                                 // Pause playback
    playerController.play();                                                  // Start/resume playback
    playerController.seekToPosition(10_000L);                                 // Seek to 10 seconds from the beginning of the media
    playerController.stop();                                                  // Stop playback
    playerController.skipToNextItem();                                        // Skip to the next item in the playback queue
    playerController.skipToPreviousItem();                                    // Skip to the previous item in the playback queue
    playerController.setRepeatMode(PlaybackRepeatMode.REPAT_MODE_ALL);        // Change the current repeat mode
    playerController.setShuffleMode(PlaybackShuffleMode.SHUFFLE_MODE_SONGS);  // Change the current shuffle mode
    

## Accessing The Current State Of The Player

A `MediaPlayerController` instance provides several methods for querying the current playback state, as well as providing metadata about the currently playing media. Below are a few examples:

    import com.apple.android.music.playback.controller.MediaPlayerController;
    
    MediaPlayerController playerController;

    playerController.getPlaybackState();    // Gets the current playback state (PAUSED, PLAYING, STOPPED)
    playerController.getCurrentPosition();  // Gets the position of the playback head, in milliseconds
    playerController.getDuration();         // Gets the duration of the current media, in milliseconds
    
    PlayerQueueItem currentQueueItem = playerController.getCurrentItem();        // Gets the currently playing playback queue item
    List<PlayerQueueIte> upcomingQueueItems = playerController.getQueueItems();  // Gets the list of playback queue items after the current item
    PlayerMediaItem currentMediaItem = currentQueueItem.getItem();               // Gets the media item associated with the playback queue item
    currentMediaItem.getTitle();                                                 // Gets the title of the media
    currentMediaItem.getAlbumTitle();                                            // Gets the title of the album the media belongs to
    currentMediaItem.getArtistName();                                            // Gets the name of the artist of the media

## Listening For State Changes

All of the methods on `MediaPlayerController` which modify the state of the player are asynchronous. In order to be notified of changes in player state, you can register a listener on the controller, which will call callback methods whenever the player state changes. Note that the player maintains a strong reference to listeners, so you should unregister them if they have a shorter lifetime than the player itself.

    import com.apple.android.music.playback.controller.MediaPlayerController;
    import com.apple.android.music.playback.model.PlaybackState;
    
    MediaPlayerController.Listener controllerListener = new MediaPlayerController.Listener {

        @Override
        public void onPlaybackStateChanged(@NonNull MediaPlayerController playerController, @PlaybackState int previousState, @PlaybackState int currentState) {
            // Handle a change in the playback state
        }
        
        @Override
        public void onCurrentItemChanged(@NonNull MediaPlayerController playerController, @Nullable PlayerQueueItem previousItem, @Nullable PlayerQueueItem currentItem) {
            // Handle a change in the currently playing item
        }

    };
    
    MediaPlayerController playerController;
    playerController.addListener(controllerListener);     // Register the listener
    playerController.removeListener(controllerListener);  // Unregister the listener

## Determining Allowed Playback Actions

Depending on the type of media playing, as well as the state of the playback queue, some actions that affect playback state may or may not be allowed. The `MediaPlayerController` provides methods to query which actions are allowed based on the current state of the player. This can be used to enable/disable aspects of your UI. Note that the player will ignore any calls to actions which are not currently allowed.

    import com.apple.android.music.playback.controller.MediaPlayerController;
    
    MediaPlayerController playerController;
    playerController.canSeek();                // Gets whether it is possible to seek in the current media
    playerController.canSkipToNextItem();      // Gets whether it is possible to skip to the next item
    playerController.canSkipToPreviousItem();  // Gets whether it is possible to skip to the previous item

## Cleaning Up Resources

When you are done with a `MediaPlayerController`, it needs to be released to clean up any resources that it is using. You should only do this when you are finished with a playback session. After releasing, the controller is no longer usable.

    import com.apple.android.music.playback.controller.MediaPlayerController;
    
    MediaPlayerController playerController;
    playerController.release();
