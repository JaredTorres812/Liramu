package com.apple.android.music.sdk.testapp.fragment;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatRadioButton;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.apple.android.music.playback.model.AudioQuality;
import com.apple.android.music.playback.model.DolbyAtmosState;
import com.apple.android.music.playback.player.SdkMediaPlayerContext;
import com.apple.android.music.playback.preferences.MediaPlaybackPreferences;
import com.apple.android.music.sdk.testapp.R;
import com.apple.android.music.sdk.testapp.util.AppPreferences;
import com.apple.android.music.util.AudioDeviceCapabilities;
import com.apple.android.sdk.authentication.AuthenticationFactory;
import com.apple.android.sdk.authentication.AuthenticationManager;
import com.apple.android.sdk.authentication.TokenError;
import com.apple.android.sdk.authentication.TokenResult;

import java.util.HashMap;


/**
 * Copyright (C) 2017 Apple, Inc. All rights reserved.
 */
public final class SettingsFragment extends BaseFragment {

    public static final String TAG = "SettingsFragment";
    private AuthenticationManager authenticationManager;
    private TextView userTokenTxtView;
    private TextView userTokenLabel;
    private static final int REQUESTCODE_APPLEMUSIC_AUTH = 3456;
    private SdkMediaPlayerContext sdkMediaPlayerContext;

    public static SettingsFragment newInstance() {
        return new SettingsFragment();
    }


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        authenticationManager = AuthenticationFactory.createAuthenticationManager(getActivity());
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        final View v = inflater.inflate(R.layout.fragment_settings, container, false);
        Button requestAccessBtn = (Button) v.findViewById(R.id.requestAccessBtn);
        requestAccessBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Use createIntentBuilder api to create the Intentbuilder which the 3rd party app can use to customize a few things
                HashMap params = new HashMap<String, String>();
                params.put("ct", "mytestCampaignToken");
                params.put("at", "mytestAffiliateToken");
                if (authenticationManager == null) {
                    authenticationManager = AuthenticationFactory.createAuthenticationManager(getActivity());
                }
                Intent intent = authenticationManager.createIntentBuilder(getString(R.string.developer_token))
                        .setHideStartScreen(false)
                        .setStartScreenMessage("To play the full song, connect CustomMusicPlayer to Apple Music. (Can be replaced by third party app's custom text message)")
                        //set this if you want to set custom params
                        .setCustomParams(params)
                        // set this if you want to have contextual upsell
                        .setContextId("1100742453")
                        // invoke build to generate the intent, make sure to use startActivityForResult if you care about the music-user-token being returned.
                        .build();
                startActivityForResult(intent, REQUESTCODE_APPLEMUSIC_AUTH);
            }
        });
        userTokenTxtView = v.findViewById(R.id.userTokenValue);
        v.findViewById(R.id.login_layout).setVisibility(View.GONE);
        userTokenLabel = v.findViewById(R.id.usertoken_label);
        setAudioQualityState(v);
        String userToken = AppPreferences.with(getActivity()).getAppleMusicUserToken();
        if (userToken != null && !userToken.isEmpty()) {
            userTokenTxtView.setText(userToken);
            userTokenLabel.setVisibility(View.VISIBLE);
        }

        return v;
    }

    @Override
    public void onStart() {
        super.onStart();
        getActivity().setTitle(getString(R.string.title_settings));
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        Log.e(TAG, "onActivityResult: " + requestCode + ", data = " + data);
        String textViewText = "";
        if (requestCode == REQUESTCODE_APPLEMUSIC_AUTH) {
            TokenResult tokenResult = authenticationManager.handleTokenResult(data);
            if (!tokenResult.isError()) {
                String musicUserToken = tokenResult.getMusicUserToken();
                String userStoreFrontId = tokenResult.getStorefrontId();
                String appleMusicStoreFrontId = tokenResult.getAppleMusicStorefrontId();
                textViewText = musicUserToken;
                AppPreferences.with(getActivity()).setAppleMusicUserToken(musicUserToken);
                AppPreferences.with(getActivity()).setAppleMusicStoreFrontId(appleMusicStoreFrontId);
            } else {
                TokenError error = tokenResult.getError();
                textViewText = "Error getting token: " + error;
            }
            userTokenTxtView.setText(textViewText);
            userTokenLabel.setVisibility(View.VISIBLE);
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    private void setAudioQualityState(View view) {
        if (sdkMediaPlayerContext==null){
            sdkMediaPlayerContext = new SdkMediaPlayerContext(this.getActivity().getApplicationContext());
        }

        AppCompatRadioButton button_atmos = view.findViewById(R.id.setting_radio_dolby_atmos);
        AppCompatRadioButton button_hi_res_lossless = view.findViewById(R.id.setting_radio_hi_res_lossless);
        AppCompatRadioButton button_lossless = view.findViewById(R.id.setting_radio_lossless);
        AppCompatRadioButton button_aac = view.findViewById(R.id.setting_radio_aac);


        button_aac.setChecked(true);
        button_hi_res_lossless.setChecked(isHighResLosslessEnabled());
        button_lossless.setChecked(isLosslessEnabled());
        final boolean isDeviceDolbyAtmosCapable = AudioDeviceCapabilities.isDolbyDigitalPlusAvailable();
        if (isDeviceDolbyAtmosCapable) {
            button_atmos.setVisibility(View.VISIBLE);
            button_atmos.setChecked(isAtmosEnabled());
        } else {
            button_atmos.setVisibility(View.GONE);
        }


        button_atmos.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) setAudioQuality(AudioQuality.DOLBY_ATMOS);
        });
        button_hi_res_lossless.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) setAudioQuality(AudioQuality.HIGH_RES_LOSSLESS);
        });
        button_lossless.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) setAudioQuality(AudioQuality.LOSSLESS);
        });
        button_aac.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) setAudioQuality(AudioQuality.NONE);
        });

    }

    private boolean isLosslessEnabled() {
        return MediaPlaybackPreferences.with(getActivity().getApplicationContext()).isLosslessEnabled() &&
                MediaPlaybackPreferences.with(getActivity().getApplicationContext()).getWifiAudioQuality().equals(AudioQuality.LOSSLESS.name());
    }

    private boolean isAtmosEnabled() {
        return MediaPlaybackPreferences.with(getActivity().getApplicationContext()).getDolbyAtmosState().equals(DolbyAtmosState.ALWAYS_ON.name());
    }

    private boolean isHighResLosslessEnabled() {
        return MediaPlaybackPreferences.with(getActivity().getApplicationContext()).isLosslessEnabled() &&
                MediaPlaybackPreferences.with(getActivity().getApplicationContext()).getWifiAudioQuality().equals(AudioQuality.HIGH_RES_LOSSLESS.name());
    }

    private void setAudioQuality(AudioQuality audioQuality) {
        MediaPlaybackPreferences.with(getActivity().getApplicationContext()).setBitStreamSwitching(false);
        switch (audioQuality){
            case DOLBY_ATMOS:
                MediaPlaybackPreferences.with(getActivity().getApplicationContext()).setDolbyAtmosState(DolbyAtmosState.ALWAYS_ON);
                MediaPlaybackPreferences.with(getActivity().getApplicationContext()).setLosslessEnabled(false);
                MediaPlaybackPreferences.with(getActivity().getApplicationContext()).setWifiAudioQuality(AudioQuality.DOLBY_ATMOS);
                break;
            case HIGH_RES_LOSSLESS:
                MediaPlaybackPreferences.with(getActivity().getApplicationContext()).setDolbyAtmosState(DolbyAtmosState.OFF);
                MediaPlaybackPreferences.with(getActivity().getApplicationContext()).setLosslessEnabled(true);
                MediaPlaybackPreferences.with(getActivity().getApplicationContext()).setWifiAudioQuality(AudioQuality.HIGH_RES_LOSSLESS);
                break;
            case LOSSLESS:
                MediaPlaybackPreferences.with(getActivity().getApplicationContext()).setDolbyAtmosState(DolbyAtmosState.OFF);
                MediaPlaybackPreferences.with(getActivity().getApplicationContext()).setLosslessEnabled(true);
                MediaPlaybackPreferences.with(getActivity().getApplicationContext()).setWifiAudioQuality(AudioQuality.LOSSLESS);
                break;
            default:
                MediaPlaybackPreferences.with(getActivity().getApplicationContext()).setDolbyAtmosState(DolbyAtmosState.OFF);
                MediaPlaybackPreferences.with(getActivity().getApplicationContext()).setLosslessEnabled(false);
                MediaPlaybackPreferences.with(getActivity().getApplicationContext()).setWifiAudioQuality(AudioQuality.HIGH_QUALITY);
        }
    }
}

