package com.apple.android.music.sdk.testapp.service

interface MediaSessionConstants {
    companion object {
        // PlaybackState Values
        const val PLAYBACK_STATE_EXTRA_AUDIO_VARIANT = "com.apple.android.music.playback.playbackstate.PLAYBACK_STATE_EXTRA_AUDIO_VARIANT"
    }
}