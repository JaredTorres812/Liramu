plugins {
    id("com.android.application") version "8.3.1"
    id("org.jetbrains.kotlin.android") version "1.9.23"
}

repositories {
    mavenCentral()
    google()
}

android {
    namespace = "com.apple.android.music.sdk.testapp"
    compileSdk = 34
    buildToolsVersion = "34.0.0"
    ndkVersion = "28.1.13356709"

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        freeCompilerArgs = listOf("-Xjvm-default=all-compatibility")
        jvmTarget = JavaVersion.VERSION_17.toString()
    }

    defaultConfig {
        applicationId = "com.apple.android.music.sdk.testapp"
        versionCode = 1
        versionName = "1.0"
        minSdk = 23
        targetSdk = 34
        vectorDrawables.useSupportLibrary = true
    }

    buildFeatures {
        buildConfig = true
    }

    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }

    packagingOptions {
        exclude("META-INF/proguard/androidx-annotations.pro")
        jniLibs.useLegacyPackaging = true
    }
}

dependencies {
    implementation("androidx.annotation:annotation:1.7.1")
    implementation("androidx.media:media:1.7.0")
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.6.1")
    implementation("com.squareup.picasso:picasso:2.5.2")
    implementation("com.google.code.gson:gson:2.8.6")
    implementation("org.jetbrains.kotlin:kotlin-stdlib-jdk7:1.9.23")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.6.0")

    implementation(files("src/main/libs/MediaPlayback-release-1.1.4.aar"))
    implementation(files("src/main/libs/MusicKitAuth-release-1.1.5.aar"))
}
